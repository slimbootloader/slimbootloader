/*
// INTEL CONFIDENTIAL
// Copyright 2013 2017 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
//
*/

/* 
// 
//  Purpose:
//     Cryptography Primitive.
//     Internal Definitions and
//     Internal ng RSA Function Prototypes
// 
// 
*/

#if !defined(_CP_NG_RSA_MONT_STUFF_H)
#define _CP_NG_RSA_MONT_STUFF_H

#include "pcpbn.h"
#include "pcpmulbnukara.h"
#include "pcpmontgomery.h"

#define MOD_MONTGOMERY_TWO_STAGES_MUL

#define MOD_ENGINE_RSA_POOL_SIZE 2

/*
// whether Karatsuba algorithm in use
//
// note MUL and SQR operations could have different "threshold" bounndary
*/
__INLINE int gsIsKaratsubaApplicable(cpSize ns, cpSize threshold)
{
   #if !defined(_USE_KARATSUBA_)
   UNREFERENCED_PARAMETER(ns);
   UNREFERENCED_PARAMETER(threshold);
   return 0;
   #else
   return ns>=threshold;
   #endif
}

/*
// length (in BNU_CHUNK_T) of buffer for Karatsuba mul/sqr operations
*/
__INLINE cpSize gsKaratsubaBufferLen(cpSize ns)
{
   #if !defined(_USE_KARATSUBA_)
   UNREFERENCED_PARAMETER(ns);
   return 0;
   #else
   cpSize len= 0;
   while(ns>=CP_KARATSUBA_MUL_THRESHOLD) {
      ns = ns - ns/2;
      len += ns*2;
   }
   return len;
   #endif
}

/*
// Montgomery engine preparation (GetSize/init/Set)
*/
#define gsMontGetSize OWNAPI(gsMontGetSize)
void gsMontGetSize(IppsExpMethod method, int length, int* pSize);

/*
// optimal size of fixed window exponentiation
*/
__INLINE cpSize gsMontExp_WinSize(cpSize bitsize)
{
   #if defined(_USE_WINDOW_EXP_)
   // new computations
   return
      #if (_IPP !=_IPP_M5)     /*limited by 6 or 4 (LOG_CACHE_LINE_SIZE); we use it for windowing-exp imtigation */
         bitsize> 4096? 6 :    /* 4096- .. .  */
         bitsize> 2666? 5 :    /* 2666 - 4095 */
      #endif
         bitsize>  717? 4 :    /*  717 - 2665 */
         bitsize>  178? 3 :    /*  178 - 716  */
         bitsize>   41? 2 : 1; /*   41 - 177  */
   #else
   UNREFERENCED_PARAMETER(bitsize);
   return 1;
   #endif
}

/*
// Montgomery encoding/decoding
*/
__INLINE cpSize gsMontEnc_BNU(BNU_CHUNK_T* pR,
                        const BNU_CHUNK_T* pXreg, cpSize nsX,
                        const gsModEngine* pMont)
{
   cpSize nsM = MOD_LEN( pMont );
   ZEXPAND_COPY_BNU(pR, nsM, pXreg, nsX);
   MOD_METHOD( pMont )->encode(pR, pR, (gsModEngine*)pMont);
   return nsM;
}

__INLINE cpSize gsMontDec_BNU(BNU_CHUNK_T* pR,
                        const BNU_CHUNK_T* pXmont,
                              gsModEngine* pMont)
{
   cpSize nsM = MOD_LEN(pMont);
   MOD_METHOD( pMont )->decode(pR, pXmont, (gsModEngine*)pMont);
   return nsM;
}

__INLINE void gsMontEnc_BN(IppsBigNumState* pRbn,
                     const IppsBigNumState* pXbn,
                           gsModEngine* pMont)
{
   BNU_CHUNK_T* pR = BN_NUMBER(pRbn);
   cpSize nsM = MOD_LEN(pMont);

   gsMontEnc_BNU(pR, BN_NUMBER(pXbn), BN_SIZE(pXbn), pMont);

   FIX_BNU(pR, nsM);
   BN_SIZE(pRbn) = nsM;
   BN_SIGN(pRbn) = ippBigNumPOS;
}

/*
// binary montgomery exponentiation ("fast" version)
*/
#define gsMontExpBin_BNU OWNAPI(gsMontExpBin_BNU)
cpSize gsMontExpBin_BNU(BNU_CHUNK_T* dataY,
                  const BNU_CHUNK_T* dataX, cpSize nsX,
                  const BNU_CHUNK_T* dataE, cpSize nsE,
                        gsModEngine* pMont,
                        BNU_CHUNK_T* pBuffer);

/*
// fixed-size window montgomery exponentiation ("fast" version)
*/
#if defined(_USE_WINDOW_EXP_)
cpSize gsMontExpWin_BNU(BNU_CHUNK_T* pY,
                 const BNU_CHUNK_T* pX, cpSize nsX,
                 const BNU_CHUNK_T* dataE, cpSize nsE,
                       gsModEngine* pMont,
                       BNU_CHUNK_T* pBuffer);
#endif

/*
// binary montgomery exponentiation ("safe" version)
*/
__INLINE cpSize gsPrecompResourcelen(int n, cpSize nsM)
{
//   cpSize nsR = (((sizeof(BNU_CHUNK_T)*nsM*n + (CACHE_LINE_SIZE-1)))/CACHE_LINE_SIZE)  /* num of cashe lines */
//                *MASK_BNU_CHUNK(CACHE_LINE_SIZE*BYTESIZE);                             /* length of line in BNU_CHUNK_T */
   cpSize nsR = sizeof(BNU_CHUNK_T)*nsM*n + (CACHE_LINE_SIZE-1);
   nsR /=CACHE_LINE_SIZE;  /* num of cashe lines */
   nsR *= (CACHE_LINE_SIZE/sizeof(BNU_CHUNK_T));
   return nsR;
}

#define gsMontExpBin_BNU_sscm OWNAPI(gsMontExpBin_BNU_sscm)
cpSize gsMontExpBin_BNU_sscm(BNU_CHUNK_T* pY,
                       const BNU_CHUNK_T* pX, cpSize nsX,
                       const BNU_CHUNK_T* pE, cpSize nsE,
                             gsModEngine* pMont,
                             BNU_CHUNK_T* pBuffer);

/*
// fixed-size window montgomery exponentiation ("safe" version)
*/
#if defined(_USE_WINDOW_EXP_)
#define gsMontExpWin_BNU_sscm OWNAPI(gsMontExpWin_BNU_sscm)
cpSize gsMontExpWin_BNU_sscm(BNU_CHUNK_T* dataY,
                       const BNU_CHUNK_T* dataX, cpSize nsX,
                       const BNU_CHUNK_T* dataE, cpSize nsE,
                             gsModEngine* pMont,
                             BNU_CHUNK_T* pBuffer);

#endif


#define gsPubBuffer_gpr OWNAPI(gsPubBuffer_gpr)
cpSize  gsPubBuffer_gpr(int modulusBits);

#define       gsMethod_RSA_gpr OWNAPI(gsMethod_RSA_gpr)
gsMethod_RSA* gsMethod_RSA_gpr(void);

#endif /* _CP_NG_RSA_MONT_STUFF_H */
