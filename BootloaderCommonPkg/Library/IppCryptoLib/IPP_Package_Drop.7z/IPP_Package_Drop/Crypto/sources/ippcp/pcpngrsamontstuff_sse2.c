/*
// INTEL CONFIDENTIAL
// Copyright 2016 2017 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
//
*/

#include "owncp.h"

#if (_IPP>=_IPP_W7) && defined(_RSA_SSE2)

#include "pcpbnuimpl.h"
#include "pcpbnumisc.h"

#include "pcpngrsa.h"
#include "pcpngrsamontstuff.h"
#include "pcpscramble.h"

#include "pcpngrsamontstuff_sse2.h"

#define RSA_SSE2_MIN_BITSIZE  (256)//(1024)
#define RSA_SSE2_MAX_BITSIZE  (13*1024)

#define NORM_DIGSIZE (BITSIZE(Ipp32u))
#define NORM_BASE   ((Ipp64u)1<<NORM_DIGSIZE)
#define NORM_MASK (NORM_BASE-1)

#define RSA_SSE2_DIGIT_SIZE   (27)
#define RSA_SSE2_DIGIT_BASE     (1<<RSA_SSE2_DIGIT_SIZE)
#define RSA_SSE2_DIGIT_MASK   (RSA_SSE2_DIGIT_BASE-1)


/* number of "diSize" chunks in "bitSize" bit string */
__INLINE int cpDigitNum(int bitSize, int digSize)
{ return (bitSize + digSize-1)/digSize; }

/* number of "RSA_SSE2_DIGIT_SIZE" chunks in "bitSize" bit string matched for AMM */
__INLINE cpSize numofVariable_sse2(int modulusBits)
{
   cpSize ammBitSize = 2 + cpDigitNum(modulusBits, BITSIZE(BNU_CHUNK_T)) * BITSIZE(BNU_CHUNK_T);
   cpSize redNum = cpDigitNum(ammBitSize, RSA_SSE2_DIGIT_SIZE);
   return redNum;
}

/* buffer corresponding to numofVariable_sse2() */
__INLINE cpSize numofVariableBuff_sse2(int numV)
{
   return numV +4 +(numV&1);
}


//gres: temporary excluded: #include <assert.h>
/*
   converts regular (base = 2^32) representation (norm, normLen)
   into "redundant" (base = 2^RSA_SSE2_DIGIT_SIZE) represenrartion (red, redLen)

   return 1

   note:
   1) repLen >= (bitsize +DIGIT_SIZE-1)/DIGIT_SIZE for complete conversion
   2) regular representation should expanded by at least one zero value,
      pre-requisite: pRegular[regLen] == 0 to make conversion correct
   3) caller must provide suitable lengths of regular and redundant respresentations
      so, conversion does correct
*/
static int regular_dig27(Ipp64u* pRep27, int repLen, const Ipp32u* pRegular, int regLen)
{
   /* expected number of digit in redundant representation */
   int n = cpDigitNum(regLen*BITSIZE(Ipp32u), RSA_SSE2_DIGIT_SIZE);

   //gres: temporary excluded: assert(pRegular[regLen]==0);  /* test pre-requisite */

   {
      int redBit;    /* output representatin bit */
      int i;
      for(i=0, redBit=0; i<n; i++, redBit+=RSA_SSE2_DIGIT_SIZE) {
         int idx   = redBit /NORM_DIGSIZE;   /* input digit number */
         int shift = redBit %NORM_DIGSIZE;   /* output digit position inside input one */
         Ipp64u x = ((Ipp64u*)(pRegular+idx))[0];
         x >>= shift;
         pRep27[i] = x & RSA_SSE2_DIGIT_MASK;
      }

      /* expands by zeros if necessary */
      for(; i<repLen; i++) {
         pRep27[i] = 0;
      }

      return 1;
   }
}

/*
   converts "redundant" (base = 2^RSA_SSE2_DIGIT_SIZE) representation (pRep27, repLen)
   into regular (base = 2^32) representation (pRegular, regLen)

   note:
   caller must provide suitable lengths of regular and redundant respresentations
   so, conversion does correct
*/
static int dig27_regular(Ipp32u* pRegular, int regLen, const Ipp64u* pRep27, int repLen)
{
   int shift = RSA_SSE2_DIGIT_SIZE;
   Ipp64u x = pRep27[0];

   int idx, i;
   for(i=1, idx=0; i<repLen && idx<regLen; i++) {
      x += pRep27[i] <<shift;
      shift += RSA_SSE2_DIGIT_SIZE;
      if(shift >= NORM_DIGSIZE) {
         pRegular[idx++] = (Ipp32u)(x & NORM_MASK);
         x >>= NORM_DIGSIZE;
         shift -= NORM_DIGSIZE;
      }
   }

   if(idx<regLen)
      pRegular[idx++] = (Ipp32u)x;

   return idx;
}

/*
   normalize "redundant" representation (pUnorm, len) into (pNorm, len)
   and returns extansion
*/
static Ipp64u cpDigit27_normalize(Ipp64u* pNorm, const Ipp64u* pUnorm, int len)
{
   int n;
   Ipp64u tmp = 0;
   for(n=0; n<len; n++) {
      tmp += pUnorm[n];
      pNorm[n] = tmp & RSA_SSE2_DIGIT_MASK;
      tmp >>= RSA_SSE2_DIGIT_SIZE;
   }
   return tmp;
}

/*
   Montgomery multiplication of the redundant operands
   (see redundant_mont_mul2_model() below for details
*/
#if 0
void redundant_mont_mul2_model(int digSize, Ipp64u* px, const Ipp64u* pa, const Ipp64u* pb, const Ipp64u* pm, Ipp64u k0, int len)
{
   /* mask of digit */
   Ipp64u digMask = ((Ipp64u)1<<digSize) -1;

   int len2 = len+2;       /* length of the buffer */
   int extLen = len+1;     /* len extension */

   /* clear result */
   int i;
   for(i=0; i<len2; i++) px[i] = 0;

   for(; len>1; len-=2) {
      Ipp64u b0 = *pb++;
      Ipp64u b1 = *pb++;

      Ipp64u ac0 = px[0];
      Ipp64u ac1 = px[1];
      Ipp64u y0, y1;

      /* for (2*i)-th iteration */
      ac0 += pa[0]* b0;
      ac1 += pa[1]* b0;
      y0  = (ac0*k0) &digMask;
      ac0 += pm[0]*y0;
      ac1 += pm[1]*y0;
      ac1 += (ac0>>digSize);

      /* for (2*i+1)-th iteration */
      ac1 += pa[0]* b1;
      y1  = (ac1*k0) &digMask;
      ac1 += pm[0]*y1;

      px[2] += (ac1>>digSize);
      for(i=2; i<extLen; i+=2) {
         Ipp64u t1 = px[i];
         Ipp64u t2 = px[i+1];

         t1 += pa[i]  *b0;
         t2 += pa[i+1]*b0;
         t1 += pm[i]  *y0;
         t2 += pm[i+1]*y0;

         t1 += pa[i-1]  *b1;
         t2 += pa[i+1-1]*b1;
         t1 += pm[i-1]  *y1;
         t2 += pm[i+1-1]*y1;

         px[i-2] = t1;
         px[i+1-2] = t2;
      }
   }

   // last b[] if is
   if(len) {
      Ipp64u b0 = *pb;
      Ipp64u ac0 = px[0] + pa[0]*b0;
      Ipp64u y0  = (ac0*k0) &digMask;
      ac0 += pm[0]*y0;

      px[1] +=  (ac0>>digSize);
      for(i=1; i<extLen; i+=2) {
         Ipp64u t1 = px[i];
         Ipp64u t2 = px[i+1];

         t1 += pa[i]  *b0;
         t2 += pa[i+1]*b0;
         t1 += pm[i]  *y0;
         t2 += pm[i+1]*y0;

         px[i-1] = t1;
         px[i+1-1] = t2;
      }
   }

   // normalize result
   len = extLen-1;
   px[len] = redundant_normalize(digSize, px, px, len);
}
#endif

static void cpMontMul_sse2(Ipp64u* pR, const Ipp64u* pA, const Ipp64u* pB, const Ipp64u* pModulus, int mLen, BNU_CHUNK_T k0, Ipp64u* pBuffer)
{
   int extLen = mLen+1; /* len extension */
   int i;

   __m128i v_k0 = _mm_shuffle_epi32(_mm_cvtsi32_si128(k0), 0x44);
   __m128i v_digMask = _mm_srli_epi64(_mm_set1_epi32(-1), 64-RSA_SSE2_DIGIT_SIZE);
   __m128i lowQword  = _mm_srli_si128(_mm_set1_epi32(-1), sizeof(Ipp64u));
   __m128i v_b0, v_y0, v_ac;

   /* clear buffer */
   v_ac = _mm_setzero_si128();
   for(i=0; i<extLen; i+=2)
      _mm_store_si128((__m128i*)(pBuffer+i), v_ac);
   _mm_storeu_si128((__m128i*)(pBuffer+mLen), v_ac);

   /* expand operands */
   _mm_storeu_si128((__m128i*)(pA+mLen), v_ac);
   _mm_storeu_si128((__m128i*)(pB+mLen), v_ac);

   /*
   // processing
   */
   for(; mLen>1; pB+=2, mLen-=2) {
      __m128i v_b1, v_y1;

      /* v_b0 = {pB[i]:pB[i]}, v_b1 = {pB[i+1]:pB[i+1]} */
      v_b1 = _mm_load_si128((__m128i*)pB);
      v_b0 = _mm_shuffle_epi32(v_b1, 0x44);
      /* v_ac = {pA[1]:pA[0]} */
      v_ac  = _mm_load_si128((__m128i*)pA);

      v_b1 = _mm_shuffle_epi32(v_b1, 0xEE);

      /* v_ac = {pA[1]:pA[0]} * {pB[i]:pB[i]} + {pR[1]:pR[0]} */
      v_ac = _mm_add_epi64(_mm_mul_epu32(v_ac, v_b0), ((__m128i*)pBuffer)[0]);
      /* v_y0 = {v_ac[0]:v_ac[0]} * {k0:k0} ) & {digMask:digMask} */
      v_y0 = _mm_mul_epu32(_mm_shuffle_epi32(v_ac, 0x44),v_k0);
      v_y0 = _mm_and_si128(v_y0, v_digMask);
      /* v_ac += v_y0 * {pM[1]:pM[0]}*/
      v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y0, ((__m128i*)pModulus)[0]));

      /* v_ac = {0: v_ac[1]+v_ac[0]>>RSA_SSE42_DIGSIZE}*/
      v_ac = _mm_add_epi64(_mm_srli_si128(v_ac, sizeof(Ipp64u)),
                           _mm_srli_epi64(_mm_and_si128(v_ac, lowQword), RSA_SSE2_DIGIT_SIZE));
      /* v_ac += {0: pA[0]} * v_b1 */
      v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_b1, _mm_cvtsi64_si128(pA[0])));

      /* v_y1 = (v_ac * v_k0) & v_digMask */
      v_y1 = _mm_and_si128(_mm_mul_epu32(v_ac, v_k0), v_digMask);

      /* v_ac += pM[0] * v_y1 */
      v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(_mm_cvtsi64_si128(pModulus[0]), v_y1));

      v_y1 = _mm_shuffle_epi32(v_y1, 0x44);

      /* pR[2] += (v_ac>>RSA_SSE42_DIGSIZE) */
      v_ac = _mm_add_epi64(_mm_srli_epi64(v_ac, RSA_SSE2_DIGIT_SIZE), ((__m128i*)pBuffer)[1]);
      _mm_store_si128(((__m128i*)pBuffer)+1, v_ac);

      for(i=2; i<extLen; i+=2) {
         v_ac = _mm_load_si128((__m128i*)(pBuffer+i));

         v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_b0, ((__m128i*)(pA+i))[0]));
         v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y0, ((__m128i*)(pModulus+i))[0]));

         v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_b1, _mm_loadu_si128((__m128i*)(pA+i-1))));
         v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y1, _mm_loadu_si128((__m128i*)(pModulus+i-1))));

         _mm_store_si128((__m128i*)(pBuffer+i-2), v_ac);
      }
   }

   /* last b[] if is */
   if(mLen) {
      v_b0 = _mm_cvtsi64_si128(pB[0]);
      v_ac = _mm_add_epi64(_mm_cvtsi64_si128(pBuffer[0]), _mm_mul_epu32(v_b0, ((__m128i*)(pA))[0]));
      v_y0 = _mm_and_si128(_mm_mul_epu32(v_ac, v_k0), v_digMask);
      v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y0, ((__m128i*)(pModulus))[0]));

      v_b0 = _mm_shuffle_epi32(v_b0, 0x44);
      v_y0 = _mm_shuffle_epi32(v_y0, 0x44);

      v_ac = _mm_add_epi64(_mm_srli_epi64(v_ac, RSA_SSE2_DIGIT_SIZE), _mm_loadu_si128((__m128i*)(pBuffer+1)));
      _mm_storeu_si128((__m128i*)(pBuffer+1), v_ac);

      for(i=1; i<extLen; i+=2) {
         v_ac = _mm_loadu_si128((__m128i*)(pBuffer+i));

         v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_b0, _mm_loadu_si128((__m128i*)(pA+i))));
         v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y0, _mm_loadu_si128((__m128i*)(pModulus+i))));

         _mm_storeu_si128((__m128i*)(pBuffer+i-1), v_ac);
      }
   }

   // normalize result
   mLen = extLen-1;
   pR[mLen] = cpDigit27_normalize(pR, pBuffer, mLen);
}

/*
   Montgomery reduction of the redundant product
   (very similar to cpMontMul_sse2() )
*/
static void cpMontRed_sse2(Ipp64u* pR, Ipp64u* pProduct, const Ipp64u* pModulus, int mLen, BNU_CHUNK_T k0)
{
   int extLen = mLen+1; /* len extension */
   int i;

   __m128i v_k0 = _mm_shuffle_epi32(_mm_cvtsi32_si128(k0), 0x44);
   __m128i v_digMask = _mm_srli_epi64(_mm_set1_epi32(-1), 64-RSA_SSE2_DIGIT_SIZE);
   __m128i lowQword  = _mm_srli_si128(_mm_set1_epi32(-1), sizeof(Ipp64u));
   __m128i v_y0, v_ac;

   v_ac = _mm_setzero_si128();

   /* expand product */
   _mm_storeu_si128((__m128i*)(pProduct+2*mLen), v_ac);

   /*
   // processing
   */
   for(; mLen>1; pProduct+=2, mLen-=2) {
      __m128i v_y1;

      /* v_ac = {pProd[1]:pProd[0]} */
      v_ac  = _mm_load_si128((__m128i*)pProduct);

      /* v_y0 = {v_ac[0]:v_ac[0]} * {k0:k0} ) & {digMask:digMask} */
      v_y0 = _mm_mul_epu32(_mm_shuffle_epi32(v_ac, 0x44),v_k0);
      v_y0 = _mm_and_si128(v_y0, v_digMask);

      /* v_ac += v_y0 * {pMod[1]:pMod[0]}*/
      v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y0, ((__m128i*)pModulus)[0]));

      /* v_ac = {0: v_ac[1]+v_ac[0]>>RSA_SSE42_DIGSIZE}*/
      v_ac = _mm_add_epi64(_mm_srli_si128(v_ac, sizeof(Ipp64u)),
                           _mm_srli_epi64(_mm_and_si128(v_ac, lowQword), RSA_SSE2_DIGIT_SIZE));

      /* v_y1 = (v_ac * v_k0) & v_digMask */
      v_y1 = _mm_and_si128(_mm_mul_epu32(v_ac, v_k0), v_digMask);

      /* v_ac += pM[0] * v_y1 */
      v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(_mm_cvtsi64_si128(pModulus[0]), v_y1));

      v_y1 = _mm_shuffle_epi32(v_y1, 0x44);

      /* pProd[2] += (v_ac>>RSA_SSE42_DIGSIZE) */
      v_ac = _mm_add_epi64(_mm_srli_epi64(v_ac, RSA_SSE2_DIGIT_SIZE), ((__m128i*)pProduct)[1]);
      _mm_store_si128(((__m128i*)pProduct)+1, v_ac);

      for(i=2; i<extLen; i+=2) {
         v_ac = _mm_load_si128((__m128i*)(pProduct+i));

         v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y0, ((__m128i*)(pModulus+i))[0]));
         v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y1, _mm_loadu_si128((__m128i*)(pModulus+i-1))));

         _mm_store_si128((__m128i*)(pProduct+i), v_ac);
      }
   }

   /* last mod[] if is */
   if(mLen) {
      v_y0 = _mm_cvtsi64_si128(pProduct[0]);
      v_y0 = _mm_and_si128(_mm_mul_epu32(v_y0, v_k0), v_digMask);
      v_y0 = _mm_shuffle_epi32(v_y0, 0x44);

      v_ac = _mm_loadu_si128((__m128i*)(pProduct));
      v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y0, ((__m128i*)(pModulus))[0]));
      /* v_ac += {v_ac[0]: v_ac[0]}>>RSA_SSE42_DIGSIZE */
      v_ac = _mm_add_epi64(v_ac, _mm_srli_epi64(_mm_shuffle_epi32(v_ac, 0x44), RSA_SSE2_DIGIT_SIZE));
      _mm_store_si128(((__m128i*)pProduct), v_ac);

      for(i=2; i<extLen; i+=2) {
         v_ac = _mm_loadu_si128((__m128i*)(pProduct+i));
         v_ac = _mm_add_epi64(v_ac, _mm_mul_epu32(v_y0, ((__m128i*)(pModulus+i))[0]));
         _mm_storeu_si128((__m128i*)(pProduct+i), v_ac);
      }

      pProduct++;
   }

   // normalize result
   mLen = extLen-1;
   pR[mLen] = cpDigit27_normalize(pR, pProduct, mLen);
}

/*
   Montgomery squaring of the redundant operand
   (see redundant_sqr_model_1() and redundant_sqr_model_2() below for details
*/
#if 0
void redundant_sqr_model_1(Ipp64u* pr, const Ipp64u* pa, int redLen, Ipp64u* pbuffer)
{
   int redLenExt = redLen+1;
   int j;
   Ipp64u* px = pbuffer;
   Ipp64u* pdbl = pbuffer+redLenExt*2;

   /* expand operand */
   ((Ipp64u*)pa)[redLen] = 0;

   /* clean buffer and double input operand */
   for(j=0; j<redLenExt; j++) {
      Ipp64u a = pa[j];
      px[j] = 0;
      px[redLenExt+j] = 0;
      pdbl[j] = a+a;
   }

   /* squaring */
   {
      int k;
      for(k=0; k<2; k++) {
         const Ipp64u* ps = pa;
         const Ipp64u* tmpa = pa+k;
         Ipp64u* px = pbuffer+k;

         int i;
         for(i=0; i<redLen; i+=2) {
            Ipp64u ai = tmpa[0];

            Ipp64u s0 = ps[0];
            Ipp64u s1 = ps[1];

            px[2*i] += ai*s0;
            px[2*i+1] += ai*s1;

            for(j=i+2; j<redLen; j++)
               px[i+j] += ai * pdbl[j];

            ps+=2;
            tmpa+=2;
         }
      }

      for(j=0; j<redLen*2; j++) {
         pr[j] = pbuffer[j];
      }
   }
}
#endif
#if 0
void cpMontSqr_sse2_v1(Ipp64u* pR, const Ipp64u* pA, const Ipp64u* pModulus, int mLen, BNU_CHUNK_T k0, Ipp64u* pScratchBuffer)
{
   int extLen = mLen+1;
   int k;

   Ipp64u* pDbl = pScratchBuffer;
   Ipp64u* pX = (Ipp64u*)(IPP_ALIGNED_PTR(pScratchBuffer+extLen, 16));

   __m128i zero = _mm_setzero_si128();

   /* expand operand */
   ((Ipp64u*)pA)[mLen] = 0;

   /* clean buffer and double input operand */
   for(k=0; k<extLen; k++) {
      Ipp64u a = pA[k];
      pX[k] = 0;
      pX[extLen+k] = 0;
      pDbl[k] = a+a;
   }

   /* squaring */
   for(k=0; k<2; k++) {
      const Ipp64u* pSgl = pA;
      const Ipp64u* tmpA = pA+k;
      Ipp64u* tmpR = pX+k;

      int i, j;
      for(i=0; i<mLen; i+=2, tmpA+=2,pSgl+=2) {
         __m128i a = _mm_shuffle_epi32(_mm_cvtsi64_si128 (tmpA[0]), 0x44);   /* {a0:a0} */
         __m128i s = _mm_load_si128((__m128i*)pSgl);                         /* {s[1]:s[0]} */

         __m128i r = _mm_loadu_si128((__m128i*)(tmpR+2*i));
         r = _mm_add_epi64(r, _mm_mul_epu32(a,s));
         _mm_storeu_si128((__m128i*)(tmpR+2*i), r);

         for(j=i+2; j<mLen; j+=2) {
            r = _mm_loadu_si128((__m128i*)(tmpR+i+j));
            r = _mm_add_epi64(r, _mm_mul_epu32(a, ((__m128i*)(pDbl+j))[0]));
            _mm_storeu_si128((__m128i*)(tmpR+i+j), r);
         }
      }
   }

   cpMontRed_sse2(pR, pX, pModulus, mLen, k0);
}
#endif

#if 0
void redundant_sqr_model_2(Ipp64u* pr, const Ipp64u* pa, int redLen, Ipp64u* pbuffer)
{
   int j;
   Ipp64u* pdbl = pbuffer;
   //Ipp64u* pres = pbuffer+redLenExt+3;
   Ipp64u* pres = pbuffer+redLen+3;

   /* expand operand - it's possible, because of 1) */
   ((Ipp64u*)pa)[redLen] = 0;

   /* clean buffer and double input operand */
   for(j=0; j<redLen; j++) {
      Ipp64u a = pa[j];
      pres[j] = 0;
      pres[redLen+j] = 0;
      pdbl[j] = a+a;
   }
   pdbl[redLen] = 0;
   pdbl[redLen+1] = 0;
   pdbl[redLen+2] = 0;

   /* squaring */
   {
      int k;
      for(k=0; k<2; k++) {
         const Ipp64u* ps = pa;
         const Ipp64u* tmpa = pa+k;
         Ipp64u* px = pres+k;

         int i, hcounter;
         for(i=0, hcounter=(redLen+1-k)/2; hcounter>1; i+=4,hcounter-=2, tmpa+=4,ps+=4) {
            Ipp64u a0 = tmpa[0];
            Ipp64u a2 = tmpa[2];

            Ipp64u s00 = ps[0];
            Ipp64u s01 = ps[1];
            Ipp64u s20 = ps[2];
            Ipp64u s21 = ps[3];

            Ipp64u d00 = pdbl[i+2];
            Ipp64u d01 = pdbl[i+3];
            Ipp64u d20 = pdbl[i+4];
            Ipp64u d21 = pdbl[i+5];

            px[2*i]   += a0*s00;
            px[2*i+1] += a0*s01;

            px[2*i+2] += a0*d00;
            px[2*i+3] += a0*d01;

            px[2*i+4] += a0*d20 + a2*s20;
            px[2*i+5] += a0*d21 + a2*s21;

            for(j=i+6; j<redLen; j+=2) {
               d00 = pdbl[j];
               d01 = pdbl[j+1];
               px[i+j]   += a0*d00 + a2*d20;
               px[i+j+1] += a0*d01 + a2*d21;
               d20 = d00;
               d21 = d01;
            }
            px[i+j]   += a2*d20;
            px[i+j+1] += a2*d21;
         }

         if(hcounter) {
            Ipp64u a0 = tmpa[0];
            Ipp64u s0 = ps[0];
            Ipp64u s1 = ps[1];
            px[2*i] += a0*s0;
            px[2*i+1] += a0*s1;

            for(j=i+2; j<redLen; j++)
               px[i+j] += a0 * pdbl[j];
         }
      }

      for(j=0; j<redLen*2; j++) {
         pr[j] = pres[j];
      }
   }
}
#endif

static void cpMontSqr_sse2(Ipp64u* pR, const Ipp64u* pA, const Ipp64u* pModulus, int mLen, BNU_CHUNK_T k0, Ipp64u* pScratchBuffer)
{
   //int extLen = mLen+1;
   int k;

   Ipp64u* pDbl = pScratchBuffer;
   Ipp64u* pX = (Ipp64u*)(IPP_ALIGNED_PTR(pScratchBuffer+mLen+3, 16));

   __m128i zero = _mm_setzero_si128();

   /* expand operand - it's possible, because of buffer has 2 addition entrys */
   _mm_storeu_si128((__m128i*)(pA+mLen), zero);

   /* double input operand and clean buffer */
   for(k=0; k<mLen; k+=2) {
      __m128i a = _mm_load_si128((__m128i*)(pA+k));
      _mm_store_si128((__m128i*)(pDbl+k),_mm_add_epi64(a, a));
      _mm_storeu_si128((__m128i*)(pX+2*k), zero);
      _mm_storeu_si128((__m128i*)(pX+2*k+2), zero);
   }
   _mm_storeu_si128((__m128i*)(pDbl+mLen), zero);
   _mm_storeu_si128((__m128i*)(pDbl+mLen+2), zero);

   /* squaring */
   for(k=0; k<2; k++) {
      const Ipp64u* ps = pA;
      const Ipp64u* tmpa = pA+k;
      Ipp64u* px = pX+k;

      int i, hcounter, j;
      for(i=0, hcounter=(mLen+1-k)/2; hcounter>1; i+=4,hcounter-=2, tmpa+=4,ps+=4) {
         __m128i t;
         __m128i a0 = _mm_shuffle_epi32(_mm_cvtsi64_si128 (tmpa[0]), 0x44);   /* {a0:a0} */
         __m128i a2 = _mm_shuffle_epi32(_mm_cvtsi64_si128 (tmpa[2]), 0x44);   /* {a2:a2} */

         __m128i s0 = _mm_load_si128((__m128i*)ps);
         __m128i s2 = _mm_load_si128((__m128i*)(ps+2));

         __m128i d0 = _mm_load_si128((__m128i*)(pDbl+i+2));
         __m128i d2 = _mm_load_si128((__m128i*)(pDbl+i+4));

         /* px[2*i]   += a0*s00; px[2*i+1] += a0*s01; */
         _mm_storeu_si128((__m128i*)(px+2*i), _mm_add_epi64(_mm_mul_epu32(a0,s0), _mm_loadu_si128((__m128i*)(px+2*i))));

         /* px[2*i+2] += a0*d00; px[2*i+3] += a0*d01; */
         _mm_storeu_si128((__m128i*)(px+2*i+2), _mm_add_epi64(_mm_mul_epu32(a0,d0), _mm_loadu_si128((__m128i*)(px+2*i+2))));

         /* px[2*i+4] += a0*d20 + a2*s20; px[2*i+5] += a0*d21 + a2*s21; */
         t = _mm_add_epi64(_mm_mul_epu32(a0,d2), _mm_mul_epu32(a2,s2));
         _mm_storeu_si128((__m128i*)(px+2*i+4), _mm_add_epi64(t, _mm_loadu_si128((__m128i*)(px+2*i+4))));

         for(j=i+6; j<mLen; j+=2) {
            d0 = _mm_load_si128((__m128i*)(pDbl+j));
            t = _mm_add_epi64(_mm_mul_epu32(a0,d0), _mm_mul_epu32(a2,d2));
            /* px[i+j]   += a0*d00 + a2*d20; px[i+j+1] += a0*d01 + a2*d21; */
            _mm_storeu_si128((__m128i*)(px+i+j), _mm_add_epi64(t, _mm_loadu_si128((__m128i*)(px+i+j))));
            d2 = d0;
         }
         /* px[i+j]   += a2*d20; px[i+j+1] += a2*d21; */
         _mm_storeu_si128((__m128i*)(px+i+j), _mm_add_epi64(_mm_mul_epu32(a2,d2), _mm_loadu_si128((__m128i*)(px+i+j))));
      }

      if(hcounter) {
         __m128i a0 = _mm_shuffle_epi32(_mm_cvtsi64_si128 (tmpa[0]), 0x44);   /* {a0:a0} */
         __m128i s0 = _mm_load_si128((__m128i*)ps);   /* {ps[1]:ps[0]} */
         /* px[2*i] += a0*s0; px[2*i+1] += a0*s1; */
         _mm_storeu_si128((__m128i*)(px+2*i), _mm_add_epi64(_mm_mul_epu32(a0,s0), _mm_loadu_si128((__m128i*)(px+2*i))));

         for(j=i+2; j<mLen; j++) {
            /* px[i+j] += a0 * pdbl[j]; */
            __m128i r = _mm_loadu_si128((__m128i*)(px+i+j));
            r = _mm_add_epi64(r, _mm_mul_epu32(a0, ((__m128i*)(pDbl+j))[0]));
            _mm_storeu_si128((__m128i*)(px+i+j), r);
         }
      }
   }

   cpMontRed_sse2(pR, pX, pModulus, mLen, k0);
}


/* ======= degugging section =========================================*/
//#define _RSA_SSE2_DEBUG_
#ifdef _RSA_SSE2_DEBUG_
void debugToConvMontDomain(BNU_CHUNK_T* pR,
                     const Ipp64u* redInp, const Ipp64u* redM, int redLen,
                     const BNU_CHUNK_T* pM, const BNU_CHUNK_T* pRR, int nsM, BNU_CHUNK_T k0,
                     Ipp64u* pBuffer)
{
   Ipp64u one[152] = {
      1,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,
      0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,
      0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,
      0,0,0,0,0,0,0,0
   };
   __ALIGN16 Ipp64u redT[152];
   cpMontMul_sse2(redT, redInp, one, redM, redLen, k0, pBuffer);
   dig27_regular((Ipp32u*)redT, nsM*sizeof(BNU_CHUNK_T)/sizeof(Ipp32u), redT, redLen);

   cpMontMul_BNU(pR,
                 (Ipp32u*)redT, nsM,
                 pRR,  nsM,
                 pM,   nsM, k0,
                 (Ipp32u*)pBuffer, 0);
}
#endif
/* ===================================================================*/

#if defined(_RSA_SSE2_PUBLIC_BIN_)
/*
// binary (public) exponentiation
//
// scratch buffer structure:
//    redM[redBufferLen]
//    redX[redBufferLen]
//    redY[redBufferLen]
//    redT[redBufferLen] overlapped redBuffer[redBufferLen*3]
*/
static cpSize gsMontExpBin_BNU_sse2(BNU_CHUNK_T* dataY,
                             const BNU_CHUNK_T* dataX, cpSize nsX,
                             const BNU_CHUNK_T* dataE, cpSize nsE,
                                   gsModEngine* pMont,
                                   BNU_CHUNK_T* pBufferT)
{
   const BNU_CHUNK_T* dataM = MOD_MODULUS(pMont);
   const BNU_CHUNK_T* dataRR= MOD_MNT_R2(pMont);
   cpSize nsM = MOD_LEN(pMont);
   BNU_CHUNK_T k0 = MOD_MNT_FACTOR(pMont);

   int modulusBitSize = BITSIZE_BNU(dataM, nsM);
   int convModulusBitSize = cpDigitNum(modulusBitSize, BITSIZE(BNU_CHUNK_T)) * BITSIZE(BNU_CHUNK_T);
   int modulusLen32 = BITS2WORD32_SIZE(modulusBitSize);
   int redLen = cpDigitNum(convModulusBitSize+2, RSA_SSE2_DIGIT_SIZE);
   int redBufferLen = numofVariableBuff_sse2(redLen);

   /* allocate (16-byte aligned) buffers */
   Ipp64u* redM = (Ipp64u*)(IPP_ALIGNED_PTR(pBufferT, sizeof(Ipp64u)*2));
   Ipp64u* redX = redM+redBufferLen;
   Ipp64u* redY = redX+redBufferLen;
   Ipp64u* redT = redY+redBufferLen;
   Ipp64u* redBuffer = redT;

   #ifdef _RSA_SSE2_DEBUG_
   BNU_CHUNK_T dbgValue[152];
   #endif

   /* convert modulus into reduced domain */
   ZEXPAND_COPY_BNU((BNU_CHUNK_T*)redT, nsM+1, dataM, nsM);
   regular_dig27(redM, redBufferLen, (Ipp32u*)redT,  modulusLen32);

   /* compute taget domain Montgomery converter RR' */
   ZEXPAND_BNU(redT, 0, redBufferLen);
   SET_BIT(redT, (4*redLen*RSA_SSE2_DIGIT_SIZE - 4*convModulusBitSize));
   regular_dig27(redX, redBufferLen, (Ipp32u*)redT,  modulusLen32);

   ZEXPAND_COPY_BNU((BNU_CHUNK_T*)redT, nsM+1, dataRR, nsM);
   regular_dig27(redY, redBufferLen, (Ipp32u*)redT,  modulusLen32);
   cpMontSqr_sse2(redY, redY, redM, redLen, k0, redBuffer);
   cpMontMul_sse2(redY, redY, redX, redM, redLen, k0, redBuffer);

   /* convert base to Montgomery domain */
   ZEXPAND_COPY_BNU((BNU_CHUNK_T*)redT, nsX+1, dataX, nsX);
   regular_dig27(redX, redBufferLen, (Ipp32u*)redT,  nsX*sizeof(BNU_CHUNK_T)/sizeof(Ipp32u));
   cpMontMul_sse2(redX, redX, redY, redM, redLen, k0, redBuffer);
   #ifdef _RSA_SSE2_DEBUG_
   debugToConvMontDomain(dbgValue, redX, redM, redLen, dataM, dataRR, nsM, k0, redBuffer);
   #endif

   /* init result */
   COPY_BNU(redY, redX, redLen);

   FIX_BNU(dataE, nsE);

   {
      /* execute most significant part pE */
      BNU_CHUNK_T eValue = dataE[nsE-1];
      int n = cpNLZ_BNU(eValue)+1;

      eValue <<= n;
      for(; n<BNU_CHUNK_BITS; n++, eValue<<=1) {
         /* squaring/multiplication: Y = Y*Y */
         cpMontSqr_sse2(redY, redY, redM, redLen, k0, redBuffer);
         #ifdef _RSA_SSE2_DEBUG_
         debugToConvMontDomain(dbgValue, redY, redM, redLen, dataM, dataRR, nsM, k0, redBuffer);
         #endif

         /* and multiply Y = Y*X */
         if(eValue & ((BNU_CHUNK_T)1<<(BNU_CHUNK_BITS-1))) {
            cpMontMul_sse2(redY, redY, redX, redM, redLen, k0, redBuffer);
            #ifdef _RSA_SSE2_DEBUG_
            debugToConvMontDomain(dbgValue, redY, redM, redLen, dataM, dataRR, nsM, k0, redBuffer);
            #endif
         }
      }

      /* execute rest bits of E */
      for(--nsE; nsE>0; nsE--) {
         eValue = dataE[nsE-1];

         for(n=0; n<BNU_CHUNK_BITS; n++, eValue<<=1) {
            /* squaring: Y = Y*Y */
            cpMontSqr_sse2(redY, redY, redM, redLen, k0, redBuffer);
            #ifdef _RSA_SSE2_DEBUG_
            debugToConvMontDomain(dbgValue, redY, redM, redLen, dataM, dataRR, nsM, k0, redBuffer);
            #endif

            /* and multiply: Y = Y*X */
            if(eValue & ((BNU_CHUNK_T)1<<(BNU_CHUNK_BITS-1)))
               cpMontMul_sse2(redY, redY, redX, redM, redLen, k0, redBuffer);
         }
      }
   }

   /* convert result back to regular domain */
   ZEXPAND_BNU(redX, 0, redBufferLen);
   redX[0] = 1;
   cpMontMul_sse2(redY, redY, redX, redM, redLen, k0, redBuffer);
   dig27_regular((Ipp32u*)dataY, nsM*sizeof(BNU_CHUNK_T)/sizeof(ipp32u), redY, redLen);

   return nsM;
}
#endif /* _RSA_SSE2_PUBLIC_BIN_ */

#if defined(_RSA_SSE2_PUBLIC_WIN_)
/* TBD gsMontExpWin_BNU_sse2() */
#endif


#if !defined(_USE_WINDOW_EXP_)
/*
// binary (private) exponentiation
//
// scratch buffer structure:
//    redX[redBufferLen]
//    redT[redBufferLen]
//    redY[redBufferLen]
//    redM[redBufferLen]
//    redBuffer[redBufferLen*3]
*/
static cpSize gsMontExpBin_BNU_sscm_sse2(BNU_CHUNK_T* dataY,
                                   const BNU_CHUNK_T* dataX, cpSize nsX,
                                   const BNU_CHUNK_T* dataE, cpSize nsE,
                                         gsModEngine* pMont,
                                         BNU_CHUNK_T* pBufferT)
{
   const BNU_CHUNK_T* dataM = MOD_MODULUS(pMont);
   const BNU_CHUNK_T* dataRR= MOD_MNT_R2(pMont);
   cpSize nsM = MOD_LEN(pMont);
   BNU_CHUNK_T k0 = MOD_MNT_FACTOR(pMont);

   int modulusBitSize = BITSIZE_BNU(dataM, nsM);
   int convModulusBitSize = cpDigitNum(modulusBitSize, BITSIZE(BNU_CHUNK_T)) * BITSIZE(BNU_CHUNK_T);
   int modulusLen32 = BITS2WORD32_SIZE(modulusBitSize);
   int redLen = cpDigitNum(convModulusBitSize+2, RSA_SSE2_DIGIT_SIZE);
   int redBufferLen = numofVariableBuff_sse2(redLen);

   /* allocate (16-byte aligned) buffers */
   Ipp64u* redX = (Ipp64u*)(IPP_ALIGNED_PTR(pBufferT, sizeof(Ipp64u)*2));
   Ipp64u* redT = redX+redBufferLen;
   Ipp64u* redY = redT+redBufferLen;
   Ipp64u* redM = redY+redBufferLen;
   Ipp64u* redBuffer = redM+redBufferLen;

   /* convert modulus into reduced domain */
   ZEXPAND_COPY_BNU(redT, nsM+1, dataM, nsM);
   regular_dig27(redM, redBufferLen, (Ipp32u*)redT,  modulusLen32);

   /* compute taget domain Montgomery converter RR' */
   ZEXPAND_BNU(redT, 0, redBufferLen);
   SET_BIT(redT, (4*redLen*RSA_SSE2_DIGIT_SIZE - 4*convModulusBitSize));
   regular_dig27(redY, redBufferLen, (Ipp32u*)redT,  modulusLen32);

   ZEXPAND_COPY_BNU(redX, nsM+1, dataRR, nsM);
   regular_dig27(redT, redBufferLen, (Ipp32u*)redX,  modulusLen32);
   cpMontSqr_sse2(redT, redT, redM, redLen, k0, redBuffer);
   cpMontMul_sse2(redT, redT, redY, redM, redLen, k0, redBuffer);

   /* convert base to Montgomery domain */
   ZEXPAND_COPY_BNU(redY, nsX+1, dataX, nsX);
   regular_dig27(redX, redBufferLen, (Ipp32u*)redY,  nsX*sizeof(BNU_CHUNK_T)/sizeof(Ipp32u));
   cpMontMul_sse2(redX, redX, redT, redM, redLen, k0, redBuffer);

   /* init result */
   COPY_BNU(redY, redX, redLen);

   {
      cpSize i;
      BNU_CHUNK_T mask_pattern;

      /* execute most significant part pE */
      BNU_CHUNK_T eValue = dataE[nsE-1];
      int j = BNU_CHUNK_BITS - cpNLZ_BNU(eValue)-1;

      int back_step = 0;

      for(j-=1; j>=0; j--) {
         mask_pattern = (BNU_CHUNK_T)(back_step-1);

         /* T = (Y & mask_pattern) or (X & ~mask_pattern) */
         for(i=0; i<redLen; i++)
            redT[i] = (redY[i] & mask_pattern) | (redX[i] & ~mask_pattern);

         /* squaring/multiplication: Y = Y*T */
         cpMontMul_sse2(redY, redY, redT, redM, redLen, k0, redBuffer);

         /* update back_step and j */
         back_step = ((eValue>>j) & 0x1) & (back_step^1);
         j += back_step;
      }

      /* execute rest bits of E */
      for(--nsE; nsE>0; nsE--) {
         eValue = dataE[nsE-1];

         for(j=BNU_CHUNK_BITS-1; j>=0; j--) {
            mask_pattern = (BNU_CHUNK_T)(back_step-1);

            /* T = (Y & mask_pattern) or (X & ~mask_pattern) */
            for(i=0; i<redLen; i++)
               redT[i] = (redY[i] & mask_pattern) | (redX[i] & ~mask_pattern);

            /* squaring/multiplication: Y = Y*T */
            cpMontMul_sse2(redY, redY, redT, redM, redLen, k0, redBuffer);

            /* update back_step and j */
            back_step = ((eValue>>j) & 0x1) & (back_step^1);
            j += back_step;
         }
      }
   }

   /* convert result back to regular domain */
   ZEXPAND_BNU(redT, 0, redBufferLen);
   redT[0] = 1;
   cpMontMul_sse2(redY, redY, redT, redM, redLen, k0, redBuffer);
   dig27_regular((Ipp32u*)dataY, nsM*sizeof(BNU_CHUNK_T)/sizeof(ipp32u), redY, redLen);

   return nsM;
}
#endif /* ! _USE_WINDOW_EXP_ */

#if defined(_USE_WINDOW_EXP_)
/*
// window (private) exponentiation
//
// scratch buffer structure:
//    pre-computed table
//    redM[redBufferLen]
//    redY[redBufferLen]
//    redT[redBufferLen]
//    redE[redBufferLen]
//    redBuffer[redBufferLen*3]
*/
cpSize gsMontExpWin_BNU_sscm_sse2(BNU_CHUNK_T* dataY,
                            const BNU_CHUNK_T* dataX, cpSize nsX,
                            const BNU_CHUNK_T* dataE, cpSize nsE,
                                  gsModEngine* pMont,
                                  BNU_CHUNK_T* pBuffer)
{
   const BNU_CHUNK_T* dataM = MOD_MODULUS(pMont);
   const BNU_CHUNK_T* dataRR= MOD_MNT_R2(pMont);
   cpSize nsM = MOD_LEN(pMont);
   BNU_CHUNK_T k0 = MOD_MNT_FACTOR(pMont);

   int modulusBitSize = BITSIZE_BNU(dataM, nsM);
   int convModulusBitSize = cpDigitNum(modulusBitSize, BITSIZE(BNU_CHUNK_T)) * BITSIZE(BNU_CHUNK_T);
   int modulusLen32 = BITS2WORD32_SIZE(modulusBitSize);
   int redLen = cpDigitNum(convModulusBitSize+2, RSA_SSE2_DIGIT_SIZE);
   int redBufferLen = numofVariableBuff_sse2(redLen);

   cpSize expBitSize = BITSIZE_BNU(dataE, nsE);
   cpSize window = gsMontExp_WinSize(expBitSize);
   BNU_CHUNK_T wmask = (1<<window) -1;
   cpSize nPrecomute= 1<<window;
   cpSize chunkSize = CACHE_LINE_SIZE/nPrecomute;
   int n;

   /* CACHE_LINE_SIZE aligned redTable */
   Ipp64u* redTable = (Ipp64u*)(IPP_ALIGNED_PTR(pBuffer, CACHE_LINE_SIZE));
   /* other buffers have 16-byte alignment */
   Ipp64u* redM = redTable + gsPrecompResourcelen(nPrecomute, redLen);
   Ipp64u* redY = redM + redBufferLen;
   Ipp64u* redT = redY + redBufferLen;
   Ipp64u* redBuffer = redT + redBufferLen;
   Ipp64u* redE = redBuffer + redBufferLen*3;

   /* convert modulus into reduced domain */
   ZEXPAND_COPY_BNU((BNU_CHUNK_T*)redE, nsM+1, dataM, nsM);
   regular_dig27(redM, redBufferLen, (Ipp32u*)redE,  modulusLen32);

   /* compute taget domain Montgomery converter RR' */
   ZEXPAND_BNU(redT, 0, redBufferLen);
   SET_BIT(redT, (4*redLen*RSA_SSE2_DIGIT_SIZE - 4*convModulusBitSize));
   regular_dig27(redY, redBufferLen, (Ipp32u*)redT,  modulusLen32);

   ZEXPAND_COPY_BNU((BNU_CHUNK_T*)redE, nsM+1, dataRR, nsM);
   regular_dig27(redT, redBufferLen, (Ipp32u*)redE,  modulusLen32);
   cpMontSqr_sse2(redT, redT, redM, redLen, k0, redBuffer);
   cpMontMul_sse2(redT, redT, redY, redM, redLen, k0, redBuffer);

   /*
      pre-compute T[i] = X^i, i=0,.., 2^w-1
   */
   ZEXPAND_BNU(redY, 0, redBufferLen);
   redY[0] = 1;
   cpMontMul_sse2(redY, redY, redT, redM, redLen, k0, redBuffer);
   cpScramblePut(((Ipp8u*)redTable)+0, chunkSize, (Ipp32u*)redY, redLen*sizeof(Ipp64u)/sizeof(Ipp32u));

   ZEXPAND_COPY_BNU((BNU_CHUNK_T*)redE, nsX+1, dataX, nsX);
   regular_dig27(redY, redBufferLen, (Ipp32u*)redE,  nsX*sizeof(BNU_CHUNK_T)/sizeof(Ipp32u));
   cpMontMul_sse2(redY, redY, redT, redM, redLen, k0, redBuffer);
   cpScramblePut(((Ipp8u*)redTable)+chunkSize, chunkSize, (Ipp32u*)redY, redLen*sizeof(Ipp64u)/sizeof(Ipp32u));

   cpMontSqr_sse2(redT, redY, redM, redLen, k0, redBuffer);
   cpScramblePut(((Ipp8u*)redTable)+2*chunkSize, chunkSize, (Ipp32u*)redT, redLen*sizeof(Ipp64u)/sizeof(Ipp32u));

   for(n=3; n<nPrecomute; n++) {
      cpMontMul_sse2(redT, redT, redY, redM, redLen, k0, redBuffer);
      cpScramblePut(((Ipp8u*)redTable)+n*chunkSize, chunkSize, (Ipp32u*)redT, redLen*sizeof(Ipp64u)/sizeof(Ipp32u));
   }

   /* expand exponent */
   ZEXPAND_COPY_BNU((BNU_CHUNK_T*)redE, nsE+1, dataE, nsE);
   expBitSize = ((expBitSize+window-1)/window) *window;

   /* exponentiation */
   {
      /* position of the 1-st (left) window */
      int eBit = expBitSize - window;

      /* extract 1-st window value */
      Ipp32u eChunk = *((Ipp32u*)((Ipp16u*)redE+ eBit/BITSIZE(Ipp16u)));
      int shift = eBit & 0xF;
      cpSize windowVal = (eChunk>>shift) &wmask;

      /* initialize result */
      cpScrambleGet((Ipp32u*)redY, redLen*sizeof(Ipp64u)/sizeof(Ipp32u), ((Ipp8u*)redTable)+windowVal*chunkSize, chunkSize);

      for(eBit-=window; eBit>=0; eBit-=window) {
         /* do squaring window-times */
         for(n=0; n<window; n++) {
            cpMontSqr_sse2(redY, redY, redM, redLen, k0, redBuffer);
         }

         /* extract next window value */
         eChunk = *((Ipp32u*)((Ipp16u*)redE+ eBit/BITSIZE(Ipp16u)));
         shift = eBit & 0xF;
         windowVal = (eChunk>>shift) &wmask;
         /* exptact precomputed value and muptiply */
         cpScrambleGet((Ipp32u*)redT, redLen*sizeof(Ipp64u)/sizeof(Ipp32u), ((Ipp8u*)redTable)+windowVal*chunkSize, chunkSize);
         cpMontMul_sse2(redY, redY, redT, redM, redLen, k0, redBuffer);
      }
   }

   /* convert result back */
   ZEXPAND_BNU(redT, 0, redBufferLen);
   redT[0] = 1;
   cpMontMul_sse2(redY, redY, redT, redM, redLen, k0, redBuffer);
   dig27_regular((Ipp32u*)dataY, nsM*sizeof(BNU_CHUNK_T)/sizeof(ipp32u), redY, redLen);

   return nsM;
}
#endif /*  _USE_WINDOW_EXP_ */


/*
// definition of RSA exponentiation (SSE2 based)
*/
static cpSize gsPubBuffer_sse2(int modulusBits)
{
   #if defined(_RSA_SSE2_PUBLIC_BIN_)
   cpSize redNum = numofVariable_sse2(modulusBits);      /* "sizeof" variable */
   cpSize redBufferNum = numofVariableBuff_sse2(redNum); /* "sizeof" variable  buffer */
   redBufferNum *= sizeof(Ipp64u)/sizeof(BNU_CHUNK_T);
   return redBufferNum *7           /* 7 vaiables (maybe 6 enough?) */
        + (16/sizeof(BNU_CHUNK_T)); /* and 16-byte alignment */
   #else
   return gsPubBuffer_gpr(modulusBits);
   #endif
}

static cpSize gsPrvBuffer_sse2(int modulusBits)
{
   cpSize w = gsMontExp_WinSize(modulusBits);
   //cpSize tbl_num = (1==w)? 0 : (1<<w);
   cpSize tbl_num = (1<<w);

   cpSize bufferNum;
   cpSize redNum = numofVariable_sse2(modulusBits);
   cpSize redBufferNum = numofVariableBuff_sse2(redNum);
   redNum *= sizeof(Ipp64u)/sizeof(BNU_CHUNK_T);
   redBufferNum *= sizeof(Ipp64u)/sizeof(BNU_CHUNK_T);

   bufferNum = gsPrecompResourcelen(tbl_num, redNum) /* pre-computed table */
             + redBufferNum *7;                      /* addition 7 variables */
   return bufferNum;
}

gsMethod_RSA* gsMethod_RSA_sse2(void)
{
   static gsMethod_RSA m = {
      RSA_SSE2_MIN_BITSIZE, RSA_SSE2_MAX_BITSIZE,  // area of appication

      gsPubBuffer_sse2,
      gsPrvBuffer_sse2,

      /* public key exponentiation */
      #if defined(_RSA_SSE2_PUBLIC_WIN_)
      gsMontExpWin_BNU_sse2,        // public, window, sse2
      #elif defined(_RSA_SSE2_PUBLIC_BIN_)
      gsMontExpBin_BNU_sse2,        // public, binary, sse2
      #else
      gsMontExpBin_BNU,             // public, binary, gpr
      #endif

      /* private key exponentiation */
      #if defined(_USE_WINDOW_EXP_)
      gsMontExpWin_BNU_sscm_sse2    // private, window, sse2
      #else
      gsMontExpBin_BNU_sscm_sse2    // private, binary, sse2
      #endif
   };
   return &m;
}

#endif /* _IPP_W7 && _RSA_SSE2 */
