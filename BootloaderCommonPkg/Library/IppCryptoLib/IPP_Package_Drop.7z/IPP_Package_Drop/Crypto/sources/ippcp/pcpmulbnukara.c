/*
// INTEL CONFIDENTIAL
// Copyright 2010 2013 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
//
*/

/* 
// 
//  Purpose:
//     Cryptography Primitive.
//     BN Multiplication (Karatsuba method)
// 
//  Contents:
//     cpKaratsubaBufferSize()
//     cpMul_BNU_karatsuba()
//     cpSqr_BNU_karatsuba()
// 
// 
*/

#include "owndefs.h"
#include "owncp.h"
#include "pcpbnuarith.h"
#include "pcpmulbnukara.h"

#if defined(_USE_KARATSUBA_)
#define VALUE(x) #x
#define MY_MUL_MSG(x)    "CP_KARATSUBA_MUL_THRESHOLD:"VALUE((x))
#define MY_SQR_MSG(x)    "CP_KARATSUBA_SQR_THRESHOLD:"VALUE((x))
#pragma message(MY_MUL_MSG(CP_KARATSUBA_MUL_THRESHOLD))
#pragma message(MY_SQR_MSG(CP_KARATSUBA_SQR_THRESHOLD))

cpSize cpKaratsubaBufferSize(cpSize ns)
{
   int size = 0;
   while(ns>=CP_KARATSUBA_MUL_THRESHOLD) {
      ns = ns - ns/2;
      size += ns*2;
   }
   return size*sizeof(BNU_CHUNK_T);
}

__INLINE int TST_LT_BNU(const BNU_CHUNK_T* pA, const BNU_CHUNK_T* pB, cpSize ns)
{
   do {
      ns--;
   } while(pA[ns]==pB[ns] && ns);
   return pA[ns] < pB[ns]? -1 : 0;
}

#define add_ssaaaa(sh, sl, ah, al, bh, bl) { \
   BNU_CHUNK_T __tmp = (al) + (bl);          \
   (sh) = (ah) + (bh) + (__tmp < (al));      \
   (sl) = __tmp; \
}
#define sub_ddmmss(sh, sl, ah, al, bh, bl) { \
   BNU_CHUNK_T __tmp = (al) - (bl);          \
   (sh) = (ah) - (bh) - ((al) < (bl));       \
   (sl) = __tmp; \
}

BNU_CHUNK_T cpMul_BNU_karatsuba(BNU_CHUNK_T* pR,
                          const BNU_CHUNK_T* pX, const BNU_CHUNK_T* pY, cpSize ns,
                                BNU_CHUNK_T* pBuffer)
{
   /*
   // odd size
   */
   if(ns&1) {
      cpSize sizeL = ns >> 1;    /* of low part operand's size */
      cpSize sizeH = ns - sizeL; /* of high part operand's size */ /* note sizeH=sizeL, or sizeH=sizeL+1 */

      cpSize sizeRL = sizeL << 1;/* low parts product size */

      const BNU_CHUNK_T* pXL = pX;           /* points to the low part operand (XL) */
      const BNU_CHUNK_T* pXH = pXL + sizeL;  /* points to the hight part operand (XH) */

      const BNU_CHUNK_T* pYL = pY;           /* points to the low part operand (YL) */
      const BNU_CHUNK_T* pYH = pYL + sizeL;  /* points to the hight part operand (YH) */

      BNU_CHUNK_T* pBufX = pR;               /* points to the XH+XL (placed in the pR) */
      BNU_CHUNK_T* pBufY = pR+sizeH;         /* points to the YH+YL (placed in the pR)  */

      BNU_CHUNK_T* pBufR = pBuffer;          /* points to the temporary product (XH+XL)*(YH+YL) (placed in the Buffer) */
      BNU_CHUNK_T* pRL = pR;                 /* points to the low part product */
      BNU_CHUNK_T* pRH = pR + sizeRL;        /* points to the high part product */

      BNU_CHUNK_T carry;
      int signX = -1;
      int signY = -1;

      const BNU_CHUNK_T* pGreater = pXH;
      const BNU_CHUNK_T* pLesser  = pXL;
      BNU_CHUNK_T t = pXH[sizeH-1];
      if(0==t && TST_LT_BNU(pXH, pXL, sizeL) ) {
         signX = 0;
         pGreater = pXL;
         pLesser  = pXH;
      }
      pBufX[sizeH-1] = t -= cpSub_BNU(pBufX, pGreater, pLesser, sizeL);

      pGreater = pYH;
      pLesser  = pYL;
      t = pYH[sizeH-1];
      if(0==t && TST_LT_BNU(pYH, pYL, sizeL) ) {
         signY = 0;
         pGreater = pYL;
         pLesser  = pYH;
      }
      pBufY[sizeH-1] = t -= cpSub_BNU(pBufY, pGreater, pLesser, sizeL);

      /* point-wize products */
      if (sizeL < CP_KARATSUBA_MUL_THRESHOLD) {
         cpMul_BNU_school(pBufR, pBufX,sizeH, pBufY,sizeH);
         cpMul_BNU_school(pRL,   pXL,sizeL,   pYL,sizeL);
         cpMul_BNU_school(pRH,   pXH,sizeH,   pYH,sizeH);
      }
      else {
         cpMul_BNU_karatsuba(pBufR, pBufX,pBufY,sizeH, pBuffer+ns+1);
         cpMul_BNU_karatsuba(pRL,   pXL,  pYL,  sizeL, pBuffer+ns+1);
         cpMul_BNU_karatsuba(pRH,   pXH,  pYH,  sizeH, pBuffer+ns+1);
      }

      /* middle product */
      if(signX^signY) {
         carry = cpAddAdd_BNU(pBufR, pRL, pRH, pBufR, ns-1);
         add_ssaaaa(pBufR[ns], pBufR[ns-1], pBufR[ns], pBufR[ns-1], pRH[ns], pRH[ns-1]);
         add_ssaaaa(pBufR[ns], pBufR[ns-1], pBufR[ns], pBufR[ns-1], 0, carry);
      }
      else {
         carry = cpAddSub_BNU(pBufR, pRL, pRH, pBufR, ns-1);
         sub_ddmmss(pBufR[ns], pBufR[ns-1], pRH[ns], pRH[ns-1], pBufR[ns], pBufR[ns-1]);
         if(carry==-1)
            sub_ddmmss(pBufR[ns], pBufR[ns-1], pBufR[ns], pBufR[ns-1], 0,1);
         if(carry== 1)
            add_ssaaaa(pBufR[ns], pBufR[ns-1], pBufR[ns], pBufR[ns-1], 0,1);
      }

      /* interpolation */
      carry = cpAdd_BNU(pR+sizeL, pR+sizeL, pBufR, ns+1);
      if(carry)
         cpInc_BNU(pR+sizeL+ns+1, pR+sizeL+ns+1, sizeH-1, carry);
   }

   /*
   // even size
   */
   else {
      cpSize hsize = ns >> 1;                /* of low/high part operand's size */

      const BNU_CHUNK_T* pXL = pX;           /* points to the low part operand (XL) */
      const BNU_CHUNK_T* pXH = pXL + hsize;  /* points to the hight part operand (XH) */

      const BNU_CHUNK_T* pYL = pY;           /* points to the low part operand (YL) */
      const BNU_CHUNK_T* pYH = pYL + hsize;  /* points to the hight part operand (YH) */

      BNU_CHUNK_T* pBufX = pR;               /* points to the XH+XL (placed in the pR) */
      BNU_CHUNK_T* pBufY = pR+hsize;         /* points to the YH+YL (placed in the pR)  */

      BNU_CHUNK_T* pBufR = pBuffer;          /* points to the temporary product (XH+XL)*(YH+YL) (placed in the Buffer) */
      BNU_CHUNK_T* pRL = pR;                 /* points to the low part product */
      BNU_CHUNK_T* pRH = pR + ns;            /* points to the high part product */

      int signX = TST_LT_BNU(pXL, pXH, hsize);
      int signY = TST_LT_BNU(pYL, pYH, hsize);

      BNU_CHUNK_T carry;

      (signX<0)? cpSub_BNU(pBufX, pXH, pXL, hsize)
               : cpSub_BNU(pBufX, pXL, pXH, hsize);
      (signY<0)? cpSub_BNU(pBufY, pYH, pYL, hsize)
               : cpSub_BNU(pBufY, pYL, pYH, hsize);

      /* point-wize products */
      if (hsize < CP_KARATSUBA_MUL_THRESHOLD) {
         cpMul_BNU_school(pBufR, pBufX,hsize, pBufY,hsize);
         cpMul_BNU_school(pRL,   pXL,hsize,   pYL,hsize);
         cpMul_BNU_school(pRH,   pXH,hsize,   pYH,hsize);
      }
      else {
         cpMul_BNU_karatsuba(pBufR, pBufX,pBufY,hsize, pBuffer+ns);
         cpMul_BNU_karatsuba(pRL,   pXL,  pYL,  hsize, pBuffer+ns);
         cpMul_BNU_karatsuba(pRH,   pXH,  pYH,  hsize, pBuffer+ns);
      }

      /* middle product */
      if(signX^signY)
         carry = cpAddAdd_BNU(pBufR, pRL, pRH, pBufR, ns);
      else
         carry = cpAddSub_BNU(pBufR, pRL, pRH, pBufR, ns);

      /* interpolation */
      carry += cpAdd_BNU(pR+hsize, pR+hsize, pBufR, ns);
      if(carry)
         cpInc_BNU(pR+hsize+ns, pR+hsize+ns, hsize, carry);
   }

   return pR[2*ns-1];
}

BNU_CHUNK_T cpSqr_BNU_karatsuba(BNU_CHUNK_T* pR,
                         const BNU_CHUNK_T* pX, cpSize ns,
                               BNU_CHUNK_T* pBuffer)
{
   /*
   // odd size
   */
   if(ns&1) {
      cpSize sizeL = ns >> 1;     /* of low part operand's size */
      cpSize sizeH = ns - sizeL;  /* of high part operand's size */ /* note sizeH=sizeL, or sizeH=sizeL+1 */

      cpSize sizeRL = sizeL << 1;   /* low parts product size */

      const BNU_CHUNK_T* pXL = pX;          /* points to the low part operand (XL) */
      const BNU_CHUNK_T* pXH = pXL + sizeL; /* points to the hight part operand (XH) */

      BNU_CHUNK_T* pBufX = pR;              /* points to the XH+XL (placed in the pR) */

      BNU_CHUNK_T* pBufR = pBuffer;         /* points to the temporary product (XH+XL)*(YH+YL) (placed in the Buffer) */
      BNU_CHUNK_T* pRL = pR;                /* points to the low part product */
      BNU_CHUNK_T* pRH = pR + sizeRL;       /* points to the high part product */

      BNU_CHUNK_T carry;

      const BNU_CHUNK_T* pGreater = pXH;
      const BNU_CHUNK_T* pLesser  = pXL;
      BNU_CHUNK_T t = pXH[sizeH-1];
      if(0==t && TST_LT_BNU(pXH, pXL, sizeL) ) {
         pGreater = pXL;
         pLesser  = pXH;
      }
      pBufX[sizeH-1] = t -= cpSub_BNU(pBufX, pGreater, pLesser, sizeL);

      /* point-wize products */
      if (sizeL < CP_KARATSUBA_SQR_THRESHOLD) {
         cpSqr_BNU_school(pBufR, pBufX, sizeH);
         cpSqr_BNU_school(pRL,   pXL, sizeL);
         cpSqr_BNU_school(pRH,   pXH, sizeH);
      }
      else {
         cpSqr_BNU_karatsuba(pBufR, pBufX,sizeH, pBuffer+ns+1);
         cpSqr_BNU_karatsuba(pRL,   pXL,  sizeL, pBuffer+ns+1);
         cpSqr_BNU_karatsuba(pRH,   pXH,  sizeH, pBuffer+ns+1);
      }

      /* middle product */
      carry = cpAddSub_BNU(pBufR, pRL, pRH, pBufR, ns-1);
      sub_ddmmss(pBufR[ns], pBufR[ns-1], pRH[ns], pRH[ns-1], pBufR[ns], pBufR[ns-1]);
      if(carry==-1)
         sub_ddmmss(pBufR[ns], pBufR[ns-1], pBufR[ns], pBufR[ns-1], 0,1);
      if(carry== 1)
         add_ssaaaa(pBufR[ns], pBufR[ns-1], pBufR[ns], pBufR[ns-1], 0,1);

      /* interpolation */
      carry = cpAdd_BNU(pR+sizeL, pR+sizeL, pBufR, ns+1);
      if(carry)
         cpInc_BNU(pR+sizeL+ns+1, pR+sizeL+ns+1, sizeH-1, carry);
   }

   /*
   // even size
   */
   else {
      cpSize hsize = ns >> 1;                /* of low/high part operand's size */

      const BNU_CHUNK_T* pXL = pX;           /* points to the low part operand (XL) */
      const BNU_CHUNK_T* pXH = pXL + hsize;  /* points to the hight part operand (XH) */

      BNU_CHUNK_T* pBufX = pR;               /* points to the XH+XL (placed in the pR) */

      BNU_CHUNK_T* pBufR = pBuffer;          /* points to the temporary product (XH+XL)*(YH+YL) (placed in the Buffer) */
      BNU_CHUNK_T* pRL = pR;                 /* points to the low part product */
      BNU_CHUNK_T* pRH = pR + ns;            /* points to the high part product */

      BNU_CHUNK_T carry;

      if( TST_LT_BNU(pXL, pXH, hsize) )
         cpSub_BNU(pBufX, pXH, pXL, hsize);
      else
         cpSub_BNU(pBufX, pXL, pXH, hsize);

      /* point-wize products */
      if (hsize < CP_KARATSUBA_SQR_THRESHOLD) {
         cpSqr_BNU_school(pBufR, pBufX, hsize);
         cpSqr_BNU_school(pRL,   pXL, hsize);
         cpSqr_BNU_school(pRH,   pXH, hsize);
      }
      else {
         cpSqr_BNU_karatsuba(pBufR, pBufX,hsize, pBuffer+ns);
         cpSqr_BNU_karatsuba(pRL,   pXL,  hsize, pBuffer+ns);
         cpSqr_BNU_karatsuba(pRH,   pXH,  hsize, pBuffer+ns);
      }

      /* middle product */
      carry = cpAddSub_BNU(pBufR, pRL, pRH, pBufR, ns);

      /* interpolation */
      carry += cpAdd_BNU(pR+hsize, pR+hsize, pBufR, ns);
      if(carry)
         cpInc_BNU(pR+hsize+ns, pR+hsize+ns, hsize, carry);
   }

   return pR[2*ns-1];
}

#endif /* _USE_KARATSUBA_ */
