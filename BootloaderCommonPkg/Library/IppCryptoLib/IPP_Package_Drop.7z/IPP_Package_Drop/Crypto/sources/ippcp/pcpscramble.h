/*
// INTEL CONFIDENTIAL
// Copyright 2013 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
//
*/

/* 
// 
//  Purpose:
//     Cryptography Primitive.
//     Fixed window exponentiation scramble/unscramble
// 
//  Contents:
//     cpScramblePut()
//     cpScrambleGet()
// 
// 
*/

#if !defined(_PC_SCRAMBLE_H)
#define _PC_SCRAMBLE_H

/*
// cpsScramblePut/cpsScrambleGet
// stores to/retrieves from pScrambleEntry position
// pre-computed data if fixed window method is used
*/
__INLINE void cpScramblePut(Ipp8u* pArray, cpSize colummSize,
                      const Ipp32u* pData, cpSize dataSize)
{
   int i;
   switch(colummSize) {
      case 1: // column - byte
         dataSize *= sizeof(Ipp32u);
         for(i=0; i<dataSize; i++)
            pArray[i*CACHE_LINE_SIZE] = ((Ipp8u*)pData)[i];
         break;
      case 2: // column - word (2 bytes)
         dataSize *= sizeof(Ipp16u);
         for(i=0; i<dataSize; i++)
            ((Ipp16u*)pArray)[i*CACHE_LINE_SIZE/sizeof(Ipp16u)] = ((Ipp16u*)pData)[i];
         break;
      case 4: // column - dword (4 bytes)
         for(i=0; i<dataSize; i++)
            ((Ipp32u*)pArray)[i*CACHE_LINE_SIZE/sizeof(Ipp32u)] = pData[i];
         break;
      case 8: // column - qword (8 bytes => 2 dword)
         for(; dataSize>=2; dataSize-=2, pArray+=CACHE_LINE_SIZE, pData+=2) {
            ((Ipp32u*)pArray)[0] = pData[0];
            ((Ipp32u*)pArray)[1] = pData[1];
         }
         if(dataSize)
            ((Ipp32u*)pArray)[0] = pData[0];
         break;
      case 16: // column - oword (16 bytes => 4 dword)
         for(; dataSize>=4; dataSize-=4, pArray+=CACHE_LINE_SIZE, pData+=4) {
            ((Ipp32u*)pArray)[0] = pData[0];
            ((Ipp32u*)pArray)[1] = pData[1];
            ((Ipp32u*)pArray)[2] = pData[2];
            ((Ipp32u*)pArray)[3] = pData[3];
         }
         for(; dataSize>0; dataSize--, pArray+=sizeof(Ipp32u), pData++)
            ((Ipp32u*)pArray)[0] = pData[0];
         break;
      case 32: // column - 2 oword (32 bytes => 8 dword)
         for(; dataSize>=8; dataSize-=8, pArray+=CACHE_LINE_SIZE, pData+=8) {
            ((Ipp32u*)pArray)[0] = pData[0];
            ((Ipp32u*)pArray)[1] = pData[1];
            ((Ipp32u*)pArray)[2] = pData[2];
            ((Ipp32u*)pArray)[3] = pData[3];
            ((Ipp32u*)pArray)[4] = pData[4];
            ((Ipp32u*)pArray)[5] = pData[5];
            ((Ipp32u*)pArray)[6] = pData[6];
            ((Ipp32u*)pArray)[7] = pData[7];
         }
         for(; dataSize>0; dataSize--, pArray+=sizeof(Ipp32u), pData++)
            ((Ipp32u*)pArray)[0] = pData[0];
         break;
      default:
         break;
   }
}


/*
// Retrieve data from pArray
*/
#define u8_to_u32(b0,b1,b2,b3, x) \
  ((x) = (b0), \
   (x)|=((b1)<<8), \
   (x)|=((b2)<<16), \
   (x)|=((b3)<<24))
#define u16_to_u32(w0,w1, x) \
  ((x) = (w0), \
   (x)|=((w1)<<16))
#define u32_to_u64(dw0,dw1, x) \
  ((x) = (Ipp64u)(dw0), \
   (x)|= (((Ipp64u)(dw1))<<32))

__INLINE void cpScrambleGet(Ipp32u* pData, cpSize dataSize,
                      const Ipp8u* pArray, cpSize colummSize)
{
   int i;
   switch(colummSize) {
      case 1: // column - byte
         for(i=0; i<dataSize; i++, pArray+=sizeof(Ipp32u)*CACHE_LINE_SIZE)
            u8_to_u32(pArray[0*CACHE_LINE_SIZE], pArray[1*CACHE_LINE_SIZE], pArray[2*CACHE_LINE_SIZE], pArray[3*CACHE_LINE_SIZE], pData[i]);
         break;
      case 2: // column - word (2 bytes)
         for(i=0; i<dataSize; i++, pArray+=sizeof(Ipp16u)*CACHE_LINE_SIZE) {
            Ipp16u w0 = *((Ipp16u*)(pArray));
            Ipp16u w1 = *((Ipp16u*)(pArray+CACHE_LINE_SIZE));
            u16_to_u32( w0, w1, pData[i]);
         }
         break;
      case 4: // column - dword (4 bytes)
         for(i=0; i<dataSize; i++, pArray+=CACHE_LINE_SIZE)
            pData[i] = ((Ipp32u*)pArray)[0];
         break;
      case 8: // column - qword (8 bytes => 2 dword)
         for(; dataSize>=2; dataSize-=2, pArray+=CACHE_LINE_SIZE, pData+=2) {
            pData[0] = ((Ipp32u*)pArray)[0];
            pData[1] = ((Ipp32u*)pArray)[1];
         }
         if(dataSize)
            pData[0] = ((Ipp32u*)pArray)[0];
         break;
      case 16: // column - oword (16 bytes => 4 dword)
         for(; dataSize>=4; dataSize-=4, pArray+=CACHE_LINE_SIZE, pData+=4) {
            pData[0] = ((Ipp32u*)pArray)[0];
            pData[1] = ((Ipp32u*)pArray)[1];
            pData[2] = ((Ipp32u*)pArray)[2];
            pData[3] = ((Ipp32u*)pArray)[3];

         }
         for(; dataSize>0; dataSize--, pArray+=sizeof(Ipp32u), pData++)
            pData[0] = ((Ipp32u*)pArray)[0];
         break;
      case 32: // column - 2 oword (32 bytes => 8 dword)
         for(; dataSize>=8; dataSize-=8, pArray+=CACHE_LINE_SIZE, pData+=8) {
            pData[0] = ((Ipp32u*)pArray)[0];
            pData[1] = ((Ipp32u*)pArray)[1];
            pData[2] = ((Ipp32u*)pArray)[2];
            pData[3] = ((Ipp32u*)pArray)[3];
            pData[4] = ((Ipp32u*)pArray)[4];
            pData[5] = ((Ipp32u*)pArray)[5];
            pData[6] = ((Ipp32u*)pArray)[6];
            pData[7] = ((Ipp32u*)pArray)[7];
         }
         for(; dataSize>0; dataSize--, pArray+=sizeof(Ipp32u), pData++)
            pData[0] = ((Ipp32u*)pArray)[0];
         break;
      default:
         break;
   }
}

#endif /* _PC_SCRAMBLE_H */
