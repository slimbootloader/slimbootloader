/*
// INTEL CONFIDENTIAL
// Copyright 2017 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
//
*/

#if !defined(_GS_MOD_STUFF_H)
#define _GS_MOD_STUFF_H

//#define MONTMUL_ONESTAGE

#include "owncp.h"

#include "pcpbnuimpl.h"
#include "gsmodmethod.h"

#define MOD_ENGINE_MIN_POOL_SIZE 1

typedef struct _gsModEngine gsModEngine_T;

typedef struct _gsModEngine
{
   gsModEngine_T*       pParentME;     /* pointer to parent stuff          */
   int                  extdegree;     /* parent modulus extension (deg)   */
   int                  modBitLen;     /* length of modulus in bits        */
   int                  modLen;        /* length of modulus  (BNU_CHUNK_T) */
   int                  modLen32;      /* length of modulus  (Ipp32u)      */
   int                  peLen;         /* length of pool element (BNU_CHUNK_T) */
   const gsModMethod*   method;        /* modular arithmetic methods       */
   BNU_CHUNK_T*         pModulus;      /* modulus                          */
   BNU_CHUNK_T          k0;            /* low word of (1/modulus) mod R    */
   BNU_CHUNK_T*         pMontR;        /* mont_enc(1)                      */
   BNU_CHUNK_T*         pMontR2;       /* mont_enc(1)^2                    */
   BNU_CHUNK_T*         pHalfModulus;  /* modulus/2                        */
   BNU_CHUNK_T*         pQnr;          /* quadratic non-residue            */
   int                  poolLenUsed;   /* number of reserved temporary BNU */
   int                  poolLen;       /* max number of temporary BNU      */
   BNU_CHUNK_T*         pBuffer;       /* buffer of modLen*nBuffers length */
} gsModEngine;

/* accessory macros */
#define MOD_PARENT(eng)      ((eng)->pParentME)
#define MOD_EXTDEG(eng)      ((eng)->extdegree)
#define MOD_BITSIZE(eng)     ((eng)->modBitLen)
#define MOD_LEN(eng)         ((eng)->modLen)
#define MOD_LEN32(eng)       ((eng)->modLen32)
#define MOD_PELEN(eng)       ((eng)->peLen)
#define MOD_METHOD(eng)      ((eng)->method)
#define MOD_MODULUS(eng)     ((eng)->pModulus)
#define MOD_MNT_FACTOR(eng)  ((eng)->k0)
#define MOD_MNT_R(eng)       ((eng)->pMontR)
#define MOD_MNT_R2(eng)      ((eng)->pMontR2)
#define MOD_HMODULUS(eng)    ((eng)->pHalfModulus)
#define MOD_QNR(eng)         ((eng)->pQnr)
#define MOD_POOL_BUF(eng)    ((eng)->pBuffer)
#define MOD_MAXPOOL(eng)     ((eng)->poolLen)
#define MOD_USEDPOOL(eng)    ((eng)->poolLenUsed)

#define MOD_BUFFER(eng,n)    ((eng)->pBuffer+(MOD_PELEN(eng))*(n))

#define MOD_ENGINE_ALIGNMENT ((int)sizeof(void*))

/*
// size of context and it initialization
*/
#define   gsModEngineGetSize OWNAPI(gsModEngineGetSize)
IppStatus gsModEngineGetSize(int modulusBitSIze, int numpe, int* pSize);

#define   gsModEngineInit OWNAPI(gsModEngineInit)
IppStatus gsModEngineInit(gsModEngine* pME, const Ipp32u* pModulus, int modulusBitSize, int numpe, const gsModMethod* method);

#define     gsMontFactor OWNAPI(gsMontFactor)
BNU_CHUNK_T gsMontFactor(BNU_CHUNK_T m0);


/*
// pool management methods
*/
//#define      gsModPoolAlloc OWNAPI(gsModPoolAlloc)
//BNU_CHUNK_T* gsModPoolAlloc(gsModEngine* pME, int poolLen);

//#define gsModPoolFree OWNAPI(gsModPoolFree)
//void    gsModPoolFree(gsModEngine* pME, int poolLen);
__INLINE BNU_CHUNK_T* gsModPoolAlloc(gsModEngine* pME, int poolReq)
{
   BNU_CHUNK_T* pPool = MOD_BUFFER(pME, pME->poolLenUsed);

   if(pME->poolLenUsed + poolReq > pME->poolLen)
      pPool = NULL;
   else
      pME->poolLenUsed += poolReq;

   return pPool;
}

__INLINE void gsModPoolFree(gsModEngine* pME, int poolReq)
{
   if(pME->poolLenUsed < poolReq)
      poolReq = pME->poolLenUsed;
   pME->poolLenUsed -= poolReq;
}

/* return pointer to the top pool buffer */
#define      gsModGetPool OWNAPI(gsModGetPool)
BNU_CHUNK_T* gsModGetPool(gsModEngine* pME);

/*
// advanced operations
*/
#define alm_mont_inv OWNAPI(alm_mont_inv)
int     alm_mont_inv(BNU_CHUNK_T* pr, const BNU_CHUNK_T* pa, gsModEngine* pMA);

#define      gs_mont_inv OWNAPI(gs_mont_inv)
BNU_CHUNK_T* gs_mont_inv(BNU_CHUNK_T* pr, const BNU_CHUNK_T* pa, gsModEngine* pMA);

#define      gs_inv OWNAPI(gs_inv)
BNU_CHUNK_T* gs_inv(BNU_CHUNK_T* pr, const BNU_CHUNK_T* pa, gsModEngine* pMA);

/*
// Pack/Unpack methods
*/
#define gsPackModEngineCtx OWNAPI(gsPackModEngineCtx)
void    gsPackModEngineCtx(const gsModEngine* pCtx, Ipp8u* pBuffer);

#define gsUnpackModEngineCtx OWNAPI(gsUnpackModEngineCtx)
void    gsUnpackModEngineCtx(const Ipp8u* pBuffer, gsModEngine* pCtx);

#endif /* _GS_MOD_STUFF_H */
