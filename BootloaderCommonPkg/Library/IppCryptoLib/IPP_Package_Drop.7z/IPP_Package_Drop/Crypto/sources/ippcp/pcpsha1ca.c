/*
// INTEL CONFIDENTIAL
// Copyright 2002 2016 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
//
*/

/* 
// 
//  Purpose:
//     Cryptography Primitive.
//     Digesting message according to SHA1
// 
//  Contents:
//   - ippsSHA1GetSize()
//   - ippsSHA1Init()
//   - ippsSHA1Pack()
//   - ippsSHA1Unpack()
//   - ippsSHA1Duplicate()
//   - ippsSHA1Update()
//   - ippsSHA1GetTag()
//   - ippsSHA1Final()
//     ippsSHA1MessageDigest()
// 
// 
*/

#include "owndefs.h"
#include "owncp.h"
#include "pcphash.h"
#include "pcphash_rmf.h"
#include "pcptool.h"

/* SHA-1 constants */
static const Ipp32u sha1_iv[] = {
   0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0};

static __ALIGN16 const Ipp32u sha1_cnt[] = {
   0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xCA62C1D6
};


void sha1_hashInit(void* pHash)
{
   /* setup initial digest */
   ((Ipp32u*)pHash)[0] = sha1_iv[0];
   ((Ipp32u*)pHash)[1] = sha1_iv[1];
   ((Ipp32u*)pHash)[2] = sha1_iv[2];
   ((Ipp32u*)pHash)[3] = sha1_iv[3];
   ((Ipp32u*)pHash)[4] = sha1_iv[4];
}

void sha1_hashUpdate(void* pHash, const Ipp8u* pMsg, int msgLen)
{
   UpdateSHA1(pHash, pMsg, msgLen, sha1_cnt);
}
#if (_SHA_NI_ENABLING_==_FEATURE_TICKTOCK_ || _SHA_NI_ENABLING_==_FEATURE_ON_)
void sha1_ni_hashUpdate(void* pHash, const Ipp8u* pMsg, int msgLen)
{
   UpdateSHA1ni(pHash, pMsg, msgLen, sha1_cnt);
}
#endif

void sha1_hashOctString(Ipp8u* pMD, void* pHashVal)
{
   /* convert hash into big endian */
   ((Ipp32u*)pMD)[0] = ENDIANNESS32(((Ipp32u*)pHashVal)[0]);
   ((Ipp32u*)pMD)[1] = ENDIANNESS32(((Ipp32u*)pHashVal)[1]);
   ((Ipp32u*)pMD)[2] = ENDIANNESS32(((Ipp32u*)pHashVal)[2]);
   ((Ipp32u*)pMD)[3] = ENDIANNESS32(((Ipp32u*)pHashVal)[3]);
   ((Ipp32u*)pMD)[4] = ENDIANNESS32(((Ipp32u*)pHashVal)[4]);
}

void sha1_msgRep(Ipp8u* pDst, Ipp64u lenLo, Ipp64u lenHi)
{
   UNREFERENCED_PARAMETER(lenHi);
   lenLo = ENDIANNESS64(lenLo<<3);
   ((Ipp64u*)(pDst))[0] = lenLo;
}


/*F*
//    Name: ippsSHA1GetSize
//
// Purpose: Returns size (bytes) of IppsSHA1State state.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSize == NULL
//    ippStsNoErr             no errors
//
// Parameters:
//    pSize       pointer to state size
//
*F*/
IPPFUN(IppStatus, ippsSHA1GetSize,(int* pSize))
{
   /* test pointer */
   IPP_BAD_PTR1_RET(pSize);

   *pSize = sizeof(IppsSHA1State) +(SHA1_ALIGNMENT-1);

   return ippStsNoErr;
}


/*F*
//    Name: ippsSHA1Init
//
// Purpose: Init SHA1 state.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pState == NULL
//    ippStsNoErr             no errors
//
// Parameters:
//    pState      pointer to the SHA1 state
//
*F*/
IPPFUN(IppStatus, ippsSHA1Init,(IppsSHA1State* pState))
{
   /* test state pointer */
   IPP_BAD_PTR1_RET(pState);
   pState = (IppsSHA1State*)( IPP_ALIGNED_PTR(pState, SHA1_ALIGNMENT) );

   PaddBlock(0, pState, sizeof(IppsSHA1State));
   HASH_CTX_ID(pState) = idCtxSHA1;
   sha1_hashInit(HASH_VALUE(pState));
   return ippStsNoErr;
}


/*F*
//    Name: ippsSHA1Pack
//
// Purpose: Copy initialized context to the buffer.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSize == NULL
//                            pBuffer == NULL
//    ippStsNoErr             no errors
//
// Parameters:
//    pCtx        pointer to the hash state
//    pBuffer     pointer to the destination buffer
//
*F*/
IPPFUN(IppStatus, ippsSHA1Pack,(const IppsSHA1State* pCtx, Ipp8u* pBuffer))
{
   /* test pointers */
   IPP_BAD_PTR2_RET(pCtx, pBuffer);
   pCtx = (IppsSHA1State*)( IPP_ALIGNED_PTR(pCtx, SHA1_ALIGNMENT) );
   IPP_BADARG_RET(idCtxSHA1 !=HASH_CTX_ID(pCtx), ippStsContextMatchErr);

   CopyBlock(pCtx, pBuffer, sizeof(IppsSHA1State));
   return ippStsNoErr;
}


/*F*
//    Name: ippsSHA1Unpack
//
// Purpose: Unpack buffer content into the initialized context.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSize == NULL
//                            pBuffer == NULL
//    ippStsNoErr             no errors
//
// Parameters:
//    pBuffer     pointer to the input buffer
//    pCtx        pointer hash state
//
*F*/
IPPFUN(IppStatus, ippsSHA1Unpack,(const Ipp8u* pBuffer, IppsSHA1State* pCtx))
{
   /* test pointers */
   IPP_BAD_PTR2_RET(pCtx, pBuffer);
   pCtx = (IppsSHA1State*)( IPP_ALIGNED_PTR(pCtx, SHA1_ALIGNMENT) );

   CopyBlock(pBuffer, pCtx, sizeof(IppsSHA1State));
   return ippStsNoErr;
}


/*F*
//    Name: ippsSHA1Duplicate
//
// Purpose: Clone SHA1 state.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSrcState == NULL
//                            pDstState == NULL
//    ippStsContextMatchErr   pSrcState->idCtx != idCtxSHA1
//                            pDstState->idCtx != idCtxSHA1
//    ippStsNoErr             no errors
//
// Parameters:
//    pSrcState   pointer to the source SHA1 state
//    pDstState   pointer to the target SHA1 state
//
// Note:
//    pDstState may to be uninitialized by ippsSHA1Init()
//
*F*/
IPPFUN(IppStatus, ippsSHA1Duplicate,(const IppsSHA1State* pSrcState, IppsSHA1State* pDstState))
{
   /* test state pointers */
   IPP_BAD_PTR2_RET(pSrcState, pDstState);
   pSrcState = (IppsSHA1State*)( IPP_ALIGNED_PTR(pSrcState, SHA1_ALIGNMENT) );
   pDstState = (IppsSHA1State*)( IPP_ALIGNED_PTR(pDstState, SHA1_ALIGNMENT) );
   IPP_BADARG_RET(idCtxSHA1 !=HASH_CTX_ID(pSrcState), ippStsContextMatchErr);

   /* copy state */
   CopyBlock(pSrcState, pDstState, sizeof(IppsSHA1State));

   return ippStsNoErr;
}


/*F*
//    Name: ippsSHA1Update
//
// Purpose: Updates intermadiate digest based on input stream.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSrc == NULL
//                            pState == NULL
//    ippStsContextMatchErr   pState->idCtx != idCtxSHA1
//    ippStsLengthErr         len <0
//    ippStsNoErr             no errors
//
// Parameters:
//    pSrc        pointer to the input stream
//    len         input stream length
//    pState      pointer to the SHA1 state
//
*F*/
IPPFUN(IppStatus, ippsSHA1Update,(const Ipp8u* pSrc, int len, IppsSHA1State* pState))
{
   /* test state pointer and ID */
   IPP_BAD_PTR1_RET(pState);
   pState = (IppsSHA1State*)( IPP_ALIGNED_PTR(pState, SHA1_ALIGNMENT) );
   IPP_BADARG_RET(idCtxSHA1 !=HASH_CTX_ID(pState), ippStsContextMatchErr);

   /* test input length */
   IPP_BADARG_RET((len<0), ippStsLengthErr);
   /* test source pointer */
   IPP_BADARG_RET((len && !pSrc), ippStsNullPtrErr);

   /*
   // handle non empty message
   */
   if(len) {
      /* select processing function */
      #if (_SHA_NI_ENABLING_==_FEATURE_ON_)
      cpHashProc updateFunc = UpdateSHA1ni;
      #elif (_SHA_NI_ENABLING_==_FEATURE_TICKTOCK_)
      cpHashProc updateFunc = IsFeatureEnabled(SHA_NI_ENABLED)? UpdateSHA1ni : UpdateSHA1;
      #else
      cpHashProc updateFunc = UpdateSHA1;
      #endif

      int procLen;

      int idx = HAHS_BUFFIDX(pState);
      Ipp8u* pBuffer = HASH_BUFF(pState);
      Ipp64u lenLo = HASH_LENLO(pState) +len;

      /* if non empty internal buffer filling */
      if(idx) {
         /* copy from input stream to the internal buffer as match as possible */
         procLen = IPP_MIN(len, (MBS_SHA1-idx));
         CopyBlock(pSrc, pBuffer+idx, procLen);

         /* update message pointer and length */
         idx  += procLen;
         pSrc += procLen;
         len  -= procLen;

         /* update digest if buffer full */
         if( MBS_SHA1 == idx) {
            updateFunc(HASH_VALUE(pState), pBuffer, MBS_SHA1, sha1_cnt);
            idx = 0;
         }
      }

      /* main message part processing */
      procLen = len & ~(MBS_SHA1-1);
      if(procLen) {
         updateFunc(HASH_VALUE(pState), pSrc, procLen, sha1_cnt);
         pSrc += procLen;
         len  -= procLen;
      }

      /* store rest of message into the internal buffer */
      if(len) {
         CopyBlock(pSrc, pBuffer, len);
         idx += len;
      }

      /* update length of processed message */
      HASH_LENLO(pState) = lenLo;
      HAHS_BUFFIDX(pState) = idx;
   }

   return ippStsNoErr;
}


static void cpFinalizeSHA1(DigestSHA1 pHash, const Ipp8u* inpBuffer, int inpLen, Ipp64u processedMsgLen)
{
   /* select processing  function */
   #if (_SHA_NI_ENABLING_==_FEATURE_ON_)
   cpHashProc updateFunc = UpdateSHA1ni;
   #elif (_SHA_NI_ENABLING_==_FEATURE_TICKTOCK_)
   cpHashProc updateFunc = IsFeatureEnabled(SHA_NI_ENABLED)? UpdateSHA1ni : UpdateSHA1;
   #else
   cpHashProc updateFunc = UpdateSHA1;
   #endif

   /* local buffer and it length */
   Ipp8u buffer[MBS_SHA1*2];
   int bufferLen = inpLen < (MBS_SHA1-(int)MLR_SHA1)? MBS_SHA1 : MBS_SHA1*2; 

   /* copy rest of message into internal buffer */
   CopyBlock(inpBuffer, buffer, inpLen);

   /* padd message */
   buffer[inpLen++] = 0x80;
   PaddBlock(0, buffer+inpLen, bufferLen-inpLen-MLR_SHA1);

   /* put processed message length in bits */
   processedMsgLen = ENDIANNESS64(processedMsgLen<<3);
   ((Ipp64u*)(buffer+bufferLen))[-1] = processedMsgLen;

   /* copmplete hash computation */
   updateFunc(pHash, buffer, bufferLen, sha1_cnt);
}

/*F*
//    Name: ippsSHA1Final
//
// Purpose: Stop message digesting and return digest.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pMD == NULL
//                            pState == NULL
//    ippStsContextMatchErr   pState->idCtx != idCtxSHA1
//    ippStsNoErr             no errors
//
// Parameters:
//    pMD         address of the output digest
//    pState      pointer to the SHS state
//
*F*/
IPPFUN(IppStatus, ippsSHA1Final,(Ipp8u* pMD, IppsSHA1State* pState))
{
   /* test state pointer and ID */
   IPP_BAD_PTR1_RET(pState);
   pState = (IppsSHA1State*)( IPP_ALIGNED_PTR(pState, SHA1_ALIGNMENT) );
   IPP_BADARG_RET(idCtxSHA1 !=HASH_CTX_ID(pState), ippStsContextMatchErr);

   /* test digest pointer */
   IPP_BAD_PTR1_RET(pMD);

   cpFinalizeSHA1(HASH_VALUE(pState), HASH_BUFF(pState), HAHS_BUFFIDX(pState), HASH_LENLO(pState));
   /* convert hash into big endian */
   ((Ipp32u*)pMD)[0] = ENDIANNESS32(HASH_VALUE(pState)[0]);
   ((Ipp32u*)pMD)[1] = ENDIANNESS32(HASH_VALUE(pState)[1]);
   ((Ipp32u*)pMD)[2] = ENDIANNESS32(HASH_VALUE(pState)[2]);
   ((Ipp32u*)pMD)[3] = ENDIANNESS32(HASH_VALUE(pState)[3]);
   ((Ipp32u*)pMD)[4] = ENDIANNESS32(HASH_VALUE(pState)[4]);

   /* re-init hash value */
   HAHS_BUFFIDX(pState) = 0;
   HASH_LENLO(pState) = 0;
   sha1_hashInit(HASH_VALUE(pState));

   return ippStsNoErr;
}


/*F*
//    Name: ippsSHA1GetTag
//
// Purpose: Compute digest based on current state.
//          Note, that futher digest update is possible
//
// Returns:                Reason:
//    ippStsNullPtrErr        pTag == NULL
//                            pState == NULL
//    ippStsContextMatchErr   pState->idCtx != idCtxSHA1
//    ippStsLengthErr         max_SHA_digestLen < tagLen <1
//    ippStsNoErr             no errors
//
// Parameters:
//    pTag        address of the output digest
//    tagLen      length of digest
//    pState      pointer to the SHS state
//
*F*/
IPPFUN(IppStatus, ippsSHA1GetTag,(Ipp8u* pTag, Ipp32u tagLen, const IppsSHA1State* pState))
{
   /* test state pointer and ID */
   IPP_BAD_PTR1_RET(pState);
   pState = (IppsSHA1State*)( IPP_ALIGNED_PTR(pState, SHA1_ALIGNMENT) );
   IPP_BADARG_RET(idCtxSHA1 !=HASH_CTX_ID(pState), ippStsContextMatchErr);

   /* test digest pointer */
   IPP_BAD_PTR1_RET(pTag);
   IPP_BADARG_RET((tagLen<1)||(sizeof(DigestSHA1)<tagLen), ippStsLengthErr);

   {
      DigestSHA1 digest;
      CopyBlock(HASH_VALUE(pState), digest, sizeof(DigestSHA1));
      cpFinalizeSHA1(digest, HASH_BUFF(pState), HAHS_BUFFIDX(pState), HASH_LENLO(pState));
      digest[0] = ENDIANNESS32(digest[0]);
      digest[1] = ENDIANNESS32(digest[1]);
      digest[2] = ENDIANNESS32(digest[2]);
      digest[3] = ENDIANNESS32(digest[3]);
      digest[4] = ENDIANNESS32(digest[4]);
      CopyBlock(digest, pTag, tagLen);

      return ippStsNoErr;
   }
}


/*F*
//    Name: ippsSHA1MessageDigest
//
// Purpose: Digest of the whole message.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pMsg == NULL
//                            pMD == NULL
//    ippStsLengthErr         len <0
//    ippStsNoErr             no errors
//
// Parameters:
//    pMsg        pointer to the input message
//    len         input message length
//    pMD         address of the output digest
//
*F*/
IPPFUN(IppStatus, ippsSHA1MessageDigest,(const Ipp8u* pMsg, int msgLen, Ipp8u* pMD))
{
   /* test digest pointer */
   IPP_BAD_PTR1_RET(pMD);
   /* test message length */
   IPP_BADARG_RET((msgLen<0), ippStsLengthErr);
   /* test message pointer */
   IPP_BADARG_RET((msgLen && !pMsg), ippStsNullPtrErr);

   {
      /* select processing function */
      #if (_SHA_NI_ENABLING_==_FEATURE_ON_)
      cpHashProc updateFunc = UpdateSHA1ni;
      #elif (_SHA_NI_ENABLING_==_FEATURE_TICKTOCK_)
      cpHashProc updateFunc = IsFeatureEnabled(SHA_NI_ENABLED)? UpdateSHA1ni : UpdateSHA1;
      #else
      cpHashProc updateFunc = UpdateSHA1;
      #endif

      /* message length in the multiple MBS and the rest */
      int msgLenBlks = msgLen & (-MBS_SHA1);
      int msgLenRest = msgLen - msgLenBlks;

      /* init hash */
      ((Ipp32u*)(pMD))[0] = sha1_iv[0];
      ((Ipp32u*)(pMD))[1] = sha1_iv[1];
      ((Ipp32u*)(pMD))[2] = sha1_iv[2];
      ((Ipp32u*)(pMD))[3] = sha1_iv[3];
      ((Ipp32u*)(pMD))[4] = sha1_iv[4];

      /* process main part of the message */
      if(msgLenBlks) {
         updateFunc((Ipp32u*)pMD, pMsg, msgLenBlks, sha1_cnt);
         pMsg += msgLenBlks;
      }

      cpFinalizeSHA1((Ipp32u*)pMD, pMsg, msgLenRest, msgLen);
      ((Ipp32u*)pMD)[0] = ENDIANNESS32(((Ipp32u*)pMD)[0]);
      ((Ipp32u*)pMD)[1] = ENDIANNESS32(((Ipp32u*)pMD)[1]);
      ((Ipp32u*)pMD)[2] = ENDIANNESS32(((Ipp32u*)pMD)[2]);
      ((Ipp32u*)pMD)[3] = ENDIANNESS32(((Ipp32u*)pMD)[3]);
      ((Ipp32u*)pMD)[4] = ENDIANNESS32(((Ipp32u*)pMD)[4]);

      return ippStsNoErr;
   }
}


/*
// available SHA1 methods
*/
IPPFUN( const IppsHashMethod*, ippsHashMethod_SHA1, (void) )
{
   static IppsHashMethod method = {
      ippHashAlg_SHA1,
      IPP_SHA1_DIGEST_BITSIZE/8,
      MBS_SHA1,
      MLR_SHA1,
      sha1_hashInit,
      sha1_hashUpdate,
      sha1_hashOctString,
      sha1_msgRep
   };
   return &method;
}

IPPFUN( const IppsHashMethod*, ippsHashMethod_SHA1_NI, (void) )
{
   #if (_SHA_NI_ENABLING_==_FEATURE_TICKTOCK_ || _SHA_NI_ENABLING_==_FEATURE_ON_)
   static IppsHashMethod method = {
      ippHashAlg_SHA1,
      IPP_SHA1_DIGEST_BITSIZE/8,
      MBS_SHA1,
      MLR_SHA1,
      sha1_hashInit,
      sha1_ni_hashUpdate,
      sha1_hashOctString,
      sha1_msgRep
   };
   return &method;
   #else
   return NULL;
   #endif
}

IPPFUN( const IppsHashMethod*, ippsHashMethod_SHA1_TT, (void) )
{
   static IppsHashMethod method = {
      ippHashAlg_SHA1,
      IPP_SHA1_DIGEST_BITSIZE/8,
      MBS_SHA1,
      MLR_SHA1,
      sha1_hashInit,
      sha1_hashUpdate,
      sha1_hashOctString,
      sha1_msgRep
   };
   #if (_SHA_NI_ENABLING_==_FEATURE_TICKTOCK_ || _SHA_NI_ENABLING_==_FEATURE_ON_)
   if(IsFeatureEnabled(SHA_NI_ENABLED))
      method.hashUpdate = sha1_ni_hashUpdate;
   #endif
   return &method;
}
