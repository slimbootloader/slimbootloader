/*
// INTEL CONFIDENTIAL
// Copyright 2002 2016 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
//
*/

/* 
// 
//  Purpose:
//     Cryptography Primitive.
//     Digesting message according to MD5
//     (derived from the RSA Data Security, Inc. MD5 Message-Digest Algorithm)
// 
//     Equivalent code is available from RFC 1321.
// 
//  Contents:
//     ippsMD5GetSize()
//     ippsMD5Init()
//     ippsMD5Pack()
//     ippsMD5Unpack()
//     ippsMD5Duplicate()
//     ippsMD5Update()
//     ippsMD5GetTag()
//     ippsMD5Final()
//     ippsMD5MessageDigest()
// 
// 
*/

#include "owndefs.h"
#include "owncp.h"
#include "pcphash.h"
#include "pcphash_rmf.h"
#include "pcptool.h"

/* MD5 constants */
static const Ipp32u md5_iv[] = {
   0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476};

static __ALIGN16 const Ipp32u md5_cnt[] = {
   0xD76AA478, 0xE8C7B756, 0x242070DB, 0xC1BDCEEE,
   0xF57C0FAF, 0x4787C62A, 0xA8304613, 0xFD469501,
   0x698098D8, 0x8B44F7AF, 0xFFFF5BB1, 0x895CD7BE,
   0x6B901122, 0xFD987193, 0xA679438E, 0x49B40821,

   0xF61E2562, 0xC040B340, 0x265E5A51, 0xE9B6C7AA,
   0xD62F105D, 0x02441453, 0xD8A1E681, 0xE7D3FBC8,
   0x21E1CDE6, 0xC33707D6, 0xF4D50D87, 0x455A14ED,
   0xA9E3E905, 0xFCEFA3F8, 0x676F02D9, 0x8D2A4C8A,

   0xFFFA3942, 0x8771F681, 0x6D9D6122, 0xFDE5380C,
   0xA4BEEA44, 0x4BDECFA9, 0xF6BB4B60, 0xBEBFBC70,
   0x289B7EC6, 0xEAA127FA, 0xD4EF3085, 0x04881D05,
   0xD9D4D039, 0xE6DB99E5, 0x1FA27CF8, 0xC4AC5665,

   0xF4292244, 0x432AFF97, 0xAB9423A7, 0xFC93A039,
   0x655B59C3, 0x8F0CCC92, 0xFFEFF47D, 0x85845DD1,
   0x6FA87E4F, 0xFE2CE6E0, 0xA3014314, 0x4E0811A1,
   0xF7537E82, 0xBD3AF235, 0x2AD7D2BB, 0xEB86D391
};


void md5_hashInit(void* pHash)
{
   /* setup initial digest */
   ((Ipp32u*)pHash)[0] = md5_iv[0];
   ((Ipp32u*)pHash)[1] = md5_iv[1];
   ((Ipp32u*)pHash)[2] = md5_iv[2];
   ((Ipp32u*)pHash)[3] = md5_iv[3];
}

void md5_hashUpdate(void* pHash, const Ipp8u* pMsg, int msgLen)
{
   UpdateMD5(pHash, pMsg, msgLen, md5_cnt);
}

void md5_hashOctString(Ipp8u* pMD, void* pHashVal)
{
   /* md5 does not need conversion into big endian */
   ((Ipp32u*)pMD)[0] = ((Ipp32u*)pHashVal)[0];
   ((Ipp32u*)pMD)[1] = ((Ipp32u*)pHashVal)[1];
   ((Ipp32u*)pMD)[2] = ((Ipp32u*)pHashVal)[2];
   ((Ipp32u*)pMD)[3] = ((Ipp32u*)pHashVal)[3];
}

void md5_msgRep(Ipp8u* pDst, Ipp64u lenLo, Ipp64u lenHi)
{
   UNREFERENCED_PARAMETER(lenHi);
   lenLo <<= 3;
   ((Ipp64u*)(pDst))[0] = lenLo;
}

/*F*
//    Name: ippsMD5GetSize
//
// Purpose: Returns size (bytes) of IppsMD5State state.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSize == NULL
//    ippStsNoErr             no errors
//
// Parameters:
//    pSize       pointer to size
//
*F*/
IPPFUN(IppStatus, ippsMD5GetSize,(int* pSize))
{
   /* test pointer */
   IPP_BAD_PTR1_RET(pSize);

   *pSize = sizeof(IppsMD5State) +(MD5_ALIGNMENT-1);

   return ippStsNoErr;
}


/*F*
//    Name: ippsMD5Init
//
// Purpose: Init MD5 state.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pState == NULL
//    ippStsNoErr             no errors
//
// Parameters:
//    pState      pointer to the MD5 state
//
*F*/
IPPFUN(IppStatus, ippsMD5Init,(IppsMD5State* pState))
{
   /* test state pointer */
   IPP_BAD_PTR1_RET(pState);
   pState = (IppsMD5State*)( IPP_ALIGNED_PTR(pState, MD5_ALIGNMENT) );

   PaddBlock(0, pState, sizeof(IppsMD5State));
   HASH_CTX_ID(pState) = idCtxMD5;
   md5_hashInit(HASH_VALUE(pState));
   return ippStsNoErr;
}


/*F*
//    Name: ippsMD5Pack
//
// Purpose: Copy initialized context to the buffer.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSize == NULL
//                            pBuffer == NULL
//    ippStsNoErr             no errors
//
// Parameters:
//    pCtx        pointer hash state
//    pBuffer     pointer to the destination buffer
//
*F*/
IPPFUN(IppStatus, ippsMD5Pack,(const IppsMD5State* pCtx, Ipp8u* pBuffer))
{
   /* test pointers */
   IPP_BAD_PTR2_RET(pCtx, pBuffer);
   pCtx = (IppsMD5State*)( IPP_ALIGNED_PTR(pCtx, MD5_ALIGNMENT) );
   IPP_BADARG_RET(idCtxMD5 !=HASH_CTX_ID(pCtx), ippStsContextMatchErr);

   CopyBlock(pCtx, pBuffer, sizeof(IppsMD5State));
   return ippStsNoErr;
}


/*F*
//    Name: ippsMD5Unpack
//
// Purpose: Unpack buffer content into the initialized context.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSize == NULL
//                            pBuffer == NULL
//    ippStsNoErr             no errors
//
// Parameters:
//    pBuffer     pointer to the input buffer
//    pCtx        pointer hash state
//
*F*/
IPPFUN(IppStatus, ippsMD5Unpack,(const Ipp8u* pBuffer, IppsMD5State* pCtx))
{
   /* test pointers */
   IPP_BAD_PTR2_RET(pCtx, pBuffer);
   pCtx = (IppsMD5State*)( IPP_ALIGNED_PTR(pCtx, MD5_ALIGNMENT) );

   CopyBlock(pBuffer, pCtx, sizeof(IppsMD5State));
   return ippStsNoErr;
}


/*F*
//    Name: ippsMD5Duplicate
//
// Purpose: Clone MD5 state.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSrcState == NULL
//                            pDstState == NULL
//    ippStsContextMatchErr   pSrcState->idCtx != idCtxMD5
//                            pDstState->idCtx != idCtxMD5
//    ippStsNoErr             no errors
//
// Parameters:
//    pSrcState   pointer to the source MD5 state
//    pDstState   pointer to the target MD5 state
//
// Note:
//    pDstState may to be uninitialized by ippsMD5Init()
//
*F*/
IPPFUN(IppStatus, ippsMD5Duplicate,(const IppsMD5State* pSrcState, IppsMD5State* pDstState))
{
   /* test state pointers */
   IPP_BAD_PTR2_RET(pSrcState, pDstState);
   pSrcState = (IppsMD5State*)( IPP_ALIGNED_PTR(pSrcState, MD5_ALIGNMENT) );
   pDstState = (IppsMD5State*)( IPP_ALIGNED_PTR(pDstState, MD5_ALIGNMENT) );
   IPP_BADARG_RET(idCtxMD5 !=HASH_CTX_ID(pSrcState), ippStsContextMatchErr);

   /* copy state */
   CopyBlock(pSrcState, pDstState, sizeof(IppsMD5State));

   return ippStsNoErr;
}


/*F*
//    Name: ippsMD5Update
//
// Purpose: Updates intermadiate digest based on input stream.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pSrc == NULL
//                            pState == NULL
//    ippStsContextMatchErr   pState->idCtx != idCtxMD5
//    ippStsLengthErr         len <0
//    ippStsNoErr             no errors
//
// Parameters:
//    pSrc        pointer to the input stream
//    len         input stream length
//    pState      pointer to the MD5 state
//
*F*/
IPPFUN(IppStatus, ippsMD5Update,(const Ipp8u* pSrc, int len, IppsMD5State* pState))
{
   /* test state pointer and ID */
   IPP_BAD_PTR1_RET(pState);
   pState = (IppsMD5State*)( IPP_ALIGNED_PTR(pState, MD5_ALIGNMENT) );
   IPP_BADARG_RET(idCtxMD5 !=HASH_CTX_ID(pState), ippStsContextMatchErr);

   /* test input length */
   IPP_BADARG_RET((len<0), ippStsLengthErr);
   /* test source pointer */
   IPP_BADARG_RET((len && !pSrc), ippStsNullPtrErr);

   /*
   // handle non empty message
   */
   if(len) {
      int procLen;

      int idx = HAHS_BUFFIDX(pState);
      Ipp8u* pBuffer = HASH_BUFF(pState);
      Ipp64u lenLo = HASH_LENLO(pState) +len;

      /* if non empty internal buffer filling */
      if(idx) {
         /* copy from input stream to the internal buffer as match as possible */
         procLen = IPP_MIN(len, (MBS_MD5 -idx));
         CopyBlock(pSrc, pBuffer+idx, procLen);

         /* update message pointer and length */
         idx  += procLen;
         pSrc += procLen;
         len  -= procLen;

         /* update digest if buffer full */
         if( MBS_MD5 == idx) {
            UpdateMD5(HASH_VALUE(pState), pBuffer, MBS_MD5, md5_cnt);
            idx = 0;
         }
      }

      /* main message part processing */
      procLen = len & ~(MBS_MD5-1);
      if(procLen) {
         UpdateMD5(HASH_VALUE(pState), pSrc, procLen, md5_cnt);
         pSrc += procLen;
         len  -= procLen;
      }

      /* store rest of message into the internal buffer */
      if(len) {
         CopyBlock(pSrc, pBuffer, len);
         idx += len;
      }

      /* update length of processed message */
      HASH_LENLO(pState) = lenLo;
      HAHS_BUFFIDX(pState) = idx;
   }

   return ippStsNoErr;
}


/*
// Compute digest
*/
static void cpFinalizeMD5(DigestMD5 pHash, const Ipp8u* inpBuffer, int inpLen, Ipp64u processedMsgLen)
{
   /* local buffer and it length */
   Ipp8u buffer[MBS_MD5*2];
   int bufferLen = inpLen < (MBS_MD5-(int)MLR_MD5)? MBS_MD5 : MBS_MD5*2; 

   /* copy rest of message into internal buffer */
   CopyBlock(inpBuffer, buffer, inpLen);

   /* padd message */
   buffer[inpLen++] = 0x80;
   PaddBlock(0, buffer+inpLen, bufferLen-inpLen-MLR_MD5);

   /* put processed message length in bits */
   processedMsgLen <<= 3;
   ((Ipp64u*)(buffer+bufferLen))[-1] = processedMsgLen;

   /* copmplete hash computation */
   UpdateMD5(pHash, buffer, bufferLen, MD5_cnt);
}


/*F*
//    Name: ippsMD5Final
//
// Purpose: Stop message digesting and return digest.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pMD == NULL
//                            pState == NULL
//    ippStsContextMatchErr   pState->idCtx != idCtxMD5
//    ippStsNoErr             no errors
//
// Parameters:
//    pMD         address of the output digest
//    pState      pointer to the MD5 state
//
*F*/
IPPFUN(IppStatus, ippsMD5Final,(Ipp8u* pMD, IppsMD5State* pState))
{
   /* test state pointer and ID */
   IPP_BAD_PTR1_RET(pState);
   pState = (IppsMD5State*)( IPP_ALIGNED_PTR(pState, MD5_ALIGNMENT) );
   IPP_BADARG_RET(idCtxMD5 !=HASH_CTX_ID(pState), ippStsContextMatchErr);

   /* test digest pointer */
   IPP_BAD_PTR1_RET(pMD);

   cpFinalizeMD5(HASH_VALUE(pState), HASH_BUFF(pState), HAHS_BUFFIDX(pState), HASH_LENLO(pState));
   CopyBlock(HASH_VALUE(pState), pMD, sizeof(DigestMD5));

   /* re-init hash value */
   HAHS_BUFFIDX(pState) = 0;
   HASH_LENLO(pState) = 0;
   md5_hashInit(HASH_VALUE(pState));

   return ippStsNoErr;
}


/*F*
//    Name: ippsMD5GetTag
//
// Purpose: Compute digest based on current state.
//          Note, that futher digest update is possible
//
// Returns:                Reason:
//    ippStsNullPtrErr        pTag == NULL
//                            pState == NULL
//    ippStsContextMatchErr   pState->idCtx != idCtxMD5
//    ippStsLengthErr         max_MD5_digestLen < tagLen <1
//    ippStsNoErr             no errors
//
// Parameters:
//    pTag        address of the output digest
//    tagLen      length of digest
//    pState      pointer to the MD5 state
//
*F*/
IPPFUN(IppStatus, ippsMD5GetTag,(Ipp8u* pTag, Ipp32u tagLen, const IppsMD5State* pState))
{
   /* test state pointer and ID */
   IPP_BAD_PTR1_RET(pState);
   pState = (IppsMD5State*)( IPP_ALIGNED_PTR(pState, MD5_ALIGNMENT) );
   IPP_BADARG_RET(idCtxMD5 !=HASH_CTX_ID(pState), ippStsContextMatchErr);

   /* test digest pointer */
   IPP_BAD_PTR1_RET(pTag);
   IPP_BADARG_RET((tagLen<1)||(sizeof(DigestMD5)<tagLen), ippStsLengthErr);

   {
      DigestMD5 digest;
      CopyBlock(HASH_VALUE(pState), digest, sizeof(DigestMD5));
      cpFinalizeMD5(digest, HASH_BUFF(pState), HAHS_BUFFIDX(pState), HASH_LENLO(pState));
      CopyBlock(digest, pTag, tagLen);

      return ippStsNoErr;
   }
}


/*F*
//    Name: ippsMD5MessageDigest
//
// Purpose: Ddigest of the whole message.
//
// Returns:                Reason:
//    ippStsNullPtrErr        pMsg == NULL
//                            pDigest == NULL
//    ippStsLengthErr         len <0
//    ippStsNoErr             no errors
//
// Parameters:
//    pMsg        pointer to the input message
//    len         input message length
//    pMD         address of the output digest
//
*F*/
IPPFUN(IppStatus, ippsMD5MessageDigest,(const Ipp8u* pMsg, int msgLen, Ipp8u* pMD))
{
   /* test digest pointer */
   IPP_BAD_PTR1_RET(pMD);
   /* test message length */
   IPP_BADARG_RET((msgLen<0), ippStsLengthErr);
   /* test message pointer */
   IPP_BADARG_RET((msgLen && !pMsg), ippStsNullPtrErr);

   {
      /* message length in the multiple MBS and the rest */
      int msgLenBlks = msgLen & (-MBS_MD5);
      int msgLenRest = msgLen - msgLenBlks;

      /* init hash */
      /* init hash */
      ((Ipp32u*)(pMD))[0] = md5_iv[0];
      ((Ipp32u*)(pMD))[1] = md5_iv[1];
      ((Ipp32u*)(pMD))[2] = md5_iv[2];
      ((Ipp32u*)(pMD))[3] = md5_iv[3];

      /* process main part of the message */
      if(msgLenBlks) {
         UpdateMD5((Ipp32u*)pMD, pMsg, msgLenBlks, MD5_cnt);
         pMsg += msgLenBlks;
      }

      cpFinalizeMD5((Ipp32u*)pMD, pMsg, msgLenRest, msgLen);

      return ippStsNoErr;
   }
}


/*
// available MD5 methods
*/
IPPFUN( const IppsHashMethod*, ippsHashMethod_MD5, (void) )
{
   static IppsHashMethod method = {
      ippHashAlg_MD5,
      IPP_MD5_DIGEST_BITSIZE/8,
      MBS_MD5,
      MLR_MD5,
      md5_hashInit,
      md5_hashUpdate,
      md5_hashOctString,
      md5_msgRep
   };
   return &method;
}
