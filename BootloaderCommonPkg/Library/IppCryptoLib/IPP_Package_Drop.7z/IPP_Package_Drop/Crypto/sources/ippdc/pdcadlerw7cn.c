/*
// INTEL CONFIDENTIAL
// Copyright 2007 2015 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//   Purpose: Internal function for Adler-32 generator
// 
//   Contents:
//      ownsAdler32_8u
// 
//   Author: Alexander Naduev
// 
// 
*/



#include "owndc.h"
#include "pdc_anadler32.h"

#if (_IPP >= _IPP_W7) || (_IPP32E >= _IPP32E_M7)

/* Lib = W7, T7, V8, M7, U8 */
/* Caller = ippsAdler32_8u */
void ownsAdler32_8u( const Ipp8u* pSrc, int len, Ipp32u *pAdler32 )
{
    Ipp32u adler_l = *pAdler32 & 0xffff;
    Ipp32u adler_h = (*pAdler32 >> 16) & 0xffff;
    int i;

    if ( len >= 16 + 15 )
    {
        __declspec(align(16))
        __m128i t0, t1, t2, sum0, sum1, zero;
        __m128i const0 = _mm_set_epi16( 9, 10, 11, 12, 13, 14, 15, 16 );
        __m128i const1 = _mm_set_epi16( 1,  2,  3,  4,  5,  6,  7,  8 );
        Ipp32u sumTmp[4];
        int tmp, lenTmp;

        sum0 = sum1 = zero = _mm_setzero_si128();
        if ( (tmp = (int)(IPP_INT_PTR(pSrc) & 15)) != 0 )
        {
            tmp = -tmp & 15;
            for ( i = 0; i < tmp; i++ )
            {
                adler_l += (Ipp32u)pSrc[i];
                adler_h += adler_l;
            }
            len  -= tmp;
            pSrc += tmp;
        }
        sum0  = _mm_cvtsi32_si128( adler_l );
        sum1  = _mm_cvtsi32_si128( adler_h );
        for ( tmp = len >> 4; tmp >= 346; tmp -= 346 )
        {
            lenTmp = 346;
            do
            {
                t0   = _mm_slli_epi32( sum0, 4 );
                sum1 = _mm_add_epi32( sum1, t0 );
                t0   = t1 = t2 = _mm_load_si128( (__m128i*)pSrc );
                t0   = _mm_unpacklo_epi8( t0, zero );
                t0   = _mm_madd_epi16( t0, const0 );
                sum1 = _mm_add_epi32( sum1, t0 );
                t1   = _mm_unpackhi_epi8( t1, zero );
                t1   = _mm_madd_epi16( t1, const1 );
                sum1 = _mm_add_epi32( sum1, t1 );
                t2   = _mm_sad_epu8( t2, zero );
                sum0 = _mm_add_epi32( sum0, t2 );
                pSrc += 16;
            } while ( --lenTmp );
            _mm_storeu_si128( (__m128i*)sumTmp, sum0 );
            adler_l = (sumTmp[0] + sumTmp[2]) % 65521;
            _mm_storeu_si128( (__m128i*)sumTmp, sum1 );
            adler_h = (sumTmp[0] + sumTmp[1] + sumTmp[2] + sumTmp[3]) % 65521;
            sum0 = _mm_cvtsi32_si128( adler_l );
            sum1 = _mm_cvtsi32_si128( adler_h );
        }
        if ( tmp )
        {
            do
            {
                t0   = _mm_slli_epi32( sum0, 4 );
                sum1 = _mm_add_epi32( sum1, t0 );
                t0   = t1 = t2 = _mm_load_si128( (__m128i*)pSrc );
                t0   = _mm_unpacklo_epi8( t0, zero );
                t0   = _mm_madd_epi16( t0, const0 );
                sum1 = _mm_add_epi32( sum1, t0 );
                t1   = _mm_unpackhi_epi8( t1, zero );
                t1   = _mm_madd_epi16( t1, const1 );
                sum1 = _mm_add_epi32( sum1, t1 );
                t2   = _mm_sad_epu8( t2, zero );
                sum0 = _mm_add_epi32( sum0, t2 );
                pSrc += 16;
            } while ( --tmp );
            _mm_storeu_si128( (__m128i*)sumTmp, sum0 );
            adler_l = (sumTmp[0] + sumTmp[2]) % 65521;
            _mm_storeu_si128( (__m128i*)sumTmp, sum1 );
            adler_h = (sumTmp[0] + sumTmp[1] + sumTmp[2] + sumTmp[3]) % 65521;
        }
        len &= 15;
    }
    for ( i = 0; i < len; i++ )
    {
        adler_l += (Ipp32u)pSrc[i];
        adler_h += adler_l;
    }
    *pAdler32 = (adler_l % 65521) | ((adler_h % 65521) << 16);
} /* ownsAdler32_8u */

#endif

