/*
// INTEL CONFIDENTIAL
// Copyright 2004 2005 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
// 
// 
//   Created: Tue Sep 21 11:46:01 2004
// 
*/

#ifndef __OWNDC_H__
#define __OWNDC_H__

#ifndef __OWNDEFS_H__
  #include "owndefs.h"
#endif

#include "ippdc.h"

#define _MAX_NUM_FINDING_MATCH  0
#define _MATCH_GOOD             1
#define _MATCH_NICE             2
#define _MATCH_LAZY             3

typedef struct IppLZ77HuffCode32u
{
    Ipp32u code;
    Ipp32u len;
} IppLZ77HuffCode32u;

typedef struct IppLZ77HuffCode8u
{
    Ipp8u code;
    Ipp8u len;
} IppLZ77HuffCode8u;

typedef struct IppLZ77HuffCode16u
{
    Ipp16u code;
    Ipp16u len;
} IppLZ77HuffCode16u;

#define LENGTH_CODES 29
/* number of length codes, not counting the special END_BLOCK code */

#define DIST_CODES 30

#define LITERALS  256
/* number of literal bytes 0..255 */

#define L_CODES (LITERALS+1+LENGTH_CODES)

/* /////////////////////////////////////////////////////////////////////////////
//  Name:               ippsMTFFwd_8u
//  Purpose:            Performs the forward MTF transform
//
//  Parameters:
//    pSrc              Pointer to the source vector
//    pDst              Pointer to the destination vector
//    len               Length of source/destination vectors
//    pMTFState         Pointer to the structure containing parameters for
//                      the MTF transform
//  Return:
//    ippStsNullPtrErr  One or several pointer(s) is NULL
//    ippStsSizeErr     Length of the source vector is less or equal zero
//    ippStsNoErr       No errors
//
*/
IPPAPI(IppStatus, ippsMTFFwd_8u, ( const Ipp8u* pSrc, Ipp8u* pDst, int len,
                                   IppMTFState_8u* pMTFState ))

/* /////////////////////////////////////////////////////////////////////////////
//  Name:               ippsPackHuffContext_BZ2_16u8u
//  Purpose:            Performs the bzip2-specific encoding of Huffman context.
//                      Specific function for bzip2 compatibility.
//
//  Parameters:
//    pCode             Pointer to the bit buffer
//    pCodeLenBits      Number of valid bits in the bit buffer
//    pDst              Pointer to the destination vector
//    pDstLen           Pointer to the size of destination buffer on input,
//                      pointer to the resulting length of the destination vector
//                      on output
//    pEncodeHuffState  Pointer to internal state structure for bzip2 specific Huffman coding
//
//  Return:
//    ippStsNullPtrErr          One or several pointer(s) is NULL
//    ippStsSizeErr             Lengths of the source/destination vector are less
//                              or equal zero
//    ippStsDstSizeLessExpected The size of destination vector less expected
//    ippStsNoErr               No errors
//
*/
IPPAPI(IppStatus, ippsPackHuffContext_BZ2_16u8u, ( Ipp32u* pCode, int* pCodeLenBits, Ipp8u* pDst, int* pDstLen,
                                                   IppEncodeHuffState_BZ2* pEncodeHuffState ))

#endif /* __OWNDC_H__ */
/* ////////////////////////////// End of file /////////////////////////////// */

