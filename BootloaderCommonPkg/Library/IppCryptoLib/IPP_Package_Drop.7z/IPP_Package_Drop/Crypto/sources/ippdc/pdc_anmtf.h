/*
// INTEL CONFIDENTIAL
// Copyright 2005 2009 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//   Purpose: Common header file for ippDC MTF functions
// 
//   Author: Alexander Naduev
// 
// 
*/


#if !defined(__PDC_ANMTF_H__)

#define __PDC_ANMTF_H__

#if !defined(__OWNDC_H__)

#include "owndc.h"

#endif

#if !defined (__OWNS_H__)

  #include "owns.h"

#endif

#if (_IPP >= _IPP_W7) || (_IPP32E >= _IPP32E_M7) || (_IPPLRB > _IPPLRB_PX)

extern void ownsMTFFwd_8u( const Ipp8u* pSrc, Ipp8u* pDst, int len, Ipp8u* pHeap );
extern void ownsMTFInv_8u( const Ipp8u* pSrc, Ipp8u* pDst, int len, Ipp8u* pHeap );

#endif /* _W7 _T7 _M7 */

#endif /* __PDC_ANMTF_H__ */

