/*
// INTEL CONFIDENTIAL
// Copyright 2017 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//
// 
//   Contents:
//       ippsDecoderLZ4_8u
// 
// 
*/
#include "owndc.h"
#include "owns.h"

#if (_IPP32E >= _IPP32E_Y8) || (_IPP >= _IPP_P8)
static void ownCopyDst(Ipp8u *pSrc, Ipp8u *pDst, int offset, int len)
{
    __m128i x16;
    Ipp64u  x8;
    Ipp32u  x4;

    int     i;
    switch (offset) {
    case 1:
        x16 = _mm_set1_epi8(*pSrc);
        for (i = 0; i < len; i += 16)
            _mm_storeu_si128((__m128i *)(pDst+i), x16);
        break;
    case 2:
        x16 = _mm_set1_epi16((short)*(Ipp16u *)pSrc);
        for (i = 0; i < len; i += 16)
            _mm_storeu_si128((__m128i *)(pDst+i), x16);
        break;
    case 3:
        x4 = *(Ipp32u *)pSrc;
        for (i = 0; i < len; i += 3)
            *(Ipp32u *)(pDst+i) = x4;
        break;
    case 4:
        x16 = _mm_set1_epi32((int)*(Ipp32u *)pSrc);
        for (i = 0; i < len; i += 16)
            _mm_storeu_si128((__m128i *)(pDst+i), x16);
        break;
    case 5:
    case 6:
    case 7:
        x8 = *(Ipp64u *)pSrc;
        for (i = 0; i < len; i += offset)
            *(Ipp64u *)(pDst+i) = x8;
        break;
    case 8:
        x8 = *(Ipp64u *)pSrc;
        for (i = 0; i < len; i += 8)
            *(Ipp64u *)(pDst+i) = x8;
        break;
    default:
        for (i = 0; i < len; i += 8)
            *(Ipp64u *)(pDst+i) = *(Ipp64u *)(pSrc+i);
        break;
    }
}
#else
static void ownCopyDst(Ipp8u *pSrc, Ipp8u *pDst, int len)
{
    int     i;
    for (i = 0; i < len; i++) {
        pDst[i] = pSrc[i];
    }
}
#endif

#if (_IPP32E >= _IPP32E_L9) || (_IPP >= _IPP_H9)
static void ownCopyDst2(Ipp8u *pSrc, Ipp8u *pDst, int offset, int len)
{
    int i;
    if (offset >= 32)
        for (i = 32; i < len; i += 32)
            _mm256_storeu_si256((__m256i *)(pDst+i), _mm256_loadu_si256(pSrc+i));
    else
        for (i = 32; i < len; i += 16)
            _mm_storeu_si128((__m128i *)(pDst+i), _mm_loadu_si128(pSrc+i));
}
#elif (_IPP32E >= _IPP32E_Y8) || (_IPP >= _IPP_P8)
static void ownCopyDst2(Ipp8u *pSrc, Ipp8u *pDst, int offset, int len)
{
    int i;
    for (i = 32; i < len; i += 16)
        _mm_storeu_si128((__m128i *)(pDst+i), _mm_loadu_si128(pSrc+i));
}
#endif

IPPFUN(IppStatus, ippsDecodeLZ4_8u,(const Ipp8u* pSrc, int srcLen, Ipp8u* pDst, int *pDstLen))
{
    Ipp8u*  pSrcCrn;
    Ipp8u*  pSrcEnd;
    Ipp8u*  pSrcLmt;
    Ipp8u*  pDstCrn;
    Ipp8u*  pDstEnd;
    Ipp8u*  pDstLmt;
    Ipp8u*  pMatch;
    int     token;
    int     copylen;
    int     offset;
    int     tmp;

    IPP_BAD_PTR3_RET(pSrc,pDst,pDstLen);
    IPP_BAD_SIZE_RET(srcLen);
    IPP_BAD_SIZE_RET(*pDstLen);

    pSrcCrn = (Ipp8u *)pSrc;
    pSrcEnd = (Ipp8u *)(pSrc + srcLen);
    pSrcLmt = pSrcEnd - 32;
    pDstCrn = pDst;
    pDstEnd = (Ipp8u *)(pDst + *pDstLen);
    pDstLmt = pDstEnd - 64;

    for (; (pSrcCrn < pSrcLmt) && (pDstCrn < pDstLmt);) {
        token = (int)*pSrcCrn++;
        copylen = token >> 4;
        if (copylen != 15) {
#if (_IPP32E >= _IPP32E_Y8) || (_IPP >= _IPP_P8)
            _mm_storeu_si128((__m128i *)pDstCrn, _mm_loadu_si128(pSrcCrn));
#else
            *(Ipp64u *)(pDstCrn)   = *(Ipp64u *)(pSrcCrn);
            *(Ipp64u *)(pDstCrn+8) = *(Ipp64u *)(pSrcCrn+8);
#endif
        } else {
            for (tmp = (int)*pSrcCrn++; tmp == 255; tmp = (int)*pSrcCrn++) {
                copylen += 255;
            }
            copylen += tmp;
#if (_IPP32E >= _IPP32E_L9) || (_IPP >= _IPP_H9)
            _mm256_storeu_si256((__m256i *)(pDstCrn), _mm256_loadu_si256(pSrcCrn));
#elif (_IPP32E >= _IPP32E_Y8) || (_IPP >= _IPP_P8)
            _mm_storeu_si128((__m128i *)(pDstCrn), _mm_loadu_si128(pSrcCrn));
            _mm_storeu_si128((__m128i *)(pDstCrn+16), _mm_loadu_si128(pSrcCrn+16));
#else
            *(Ipp64u *)(pDstCrn)    = *(Ipp64u *)(pSrcCrn);
            *(Ipp64u *)(pDstCrn+8)  = *(Ipp64u *)(pSrcCrn+8);
            *(Ipp64u *)(pDstCrn+16) = *(Ipp64u *)(pSrcCrn+16);
            *(Ipp64u *)(pDstCrn+24) = *(Ipp64u *)(pSrcCrn+24);
#endif
            if (copylen > 32) {
                if ((pDstCrn + copylen) >= (pDstLmt)) goto jmp1;
                if ((pSrcCrn + copylen) >= (pSrcLmt)) goto jmp1;
#if (_IPP32E >= _IPP32E_L9) || (_IPP >= _IPP_H9)
                for (tmp = 32; tmp < copylen; tmp += 32)
                    _mm256_storeu_si256((__m256i *)(pDstCrn+tmp), _mm256_loadu_si256(pSrcCrn+tmp));
#elif (_IPP32E >= _IPP32E_Y8) || (_IPP >= _IPP_P8)
                for (tmp = 32; tmp < copylen; tmp += 32) {
                    _mm_storeu_si128((__m128i *)(pDstCrn+tmp), _mm_loadu_si128(pSrcCrn+tmp));
                    _mm_storeu_si128((__m128i *)(pDstCrn+tmp+16), _mm_loadu_si128(pSrcCrn+tmp+16));
                }
#else
                for (tmp = 32; tmp < copylen; tmp += 32) {
                    *(Ipp64u *)(pDstCrn+tmp)    = *(Ipp64u *)(pSrcCrn+tmp);
                    *(Ipp64u *)(pDstCrn+tmp+8)  = *(Ipp64u *)(pSrcCrn+tmp+8);
                    *(Ipp64u *)(pDstCrn+tmp+16) = *(Ipp64u *)(pSrcCrn+tmp+16);
                    *(Ipp64u *)(pDstCrn+tmp+24) = *(Ipp64u *)(pSrcCrn+tmp+24);
                }
#endif
            }
        }
        pSrcCrn += copylen;
        pDstCrn += copylen;
        if (pSrcCrn >= pSrcEnd) break;
        offset = (int)*(Ipp16u *)pSrcCrn;
        pSrcCrn += 2;
        copylen = token & 0xf;
        pMatch = pDstCrn - offset;
        if (copylen == 15) {
            for (tmp = (int)*pSrcCrn++; tmp == 255; tmp = (int)*pSrcCrn++)
                copylen += 255;
            copylen += tmp;
        }
        copylen += 4;
        if ((offset >= 16) || (offset >= copylen)) {
#if (_IPP32E >= _IPP32E_Y8) || (_IPP >= _IPP_P8)
            _mm_storeu_si128((__m128i *)pDstCrn, _mm_loadu_si128(pMatch));
#else
            *(Ipp64u *)(pDstCrn)   = *(Ipp64u *)(pMatch);
            *(Ipp64u *)(pDstCrn+8) = *(Ipp64u *)(pMatch+8);
#endif
            if (copylen > 16) {
#if (_IPP32E >= _IPP32E_Y8) || (_IPP >= _IPP_P8)
                _mm_storeu_si128((__m128i *)(pDstCrn+16), _mm_loadu_si128(pMatch+16));
#else
                *(Ipp64u *)(pDstCrn+16) = *(Ipp64u *)(pMatch+16);
                *(Ipp64u *)(pDstCrn+24) = *(Ipp64u *)(pMatch+24);
#endif
                if (copylen > 32) {
                    if ((pDstCrn + copylen) >= (pDstLmt)) goto jmp2;
#if (_IPP32E >= _IPP32E_Y8) || (_IPP >= _IPP_P8)
                    ownCopyDst2(pMatch, pDstCrn, offset, copylen);
#else
                    ownCopyDst(pMatch, pDstCrn, copylen);
#endif
                }
            }
        } else {
            if ((pDstCrn + copylen) >= (pDstLmt)) goto jmp2;
#if (_IPP32E >= _IPP32E_Y8) || (_IPP >= _IPP_P8)
            ownCopyDst(pMatch, pDstCrn, offset, copylen);
#else
            ownCopyDst(pMatch, pDstCrn, copylen);
#endif
        }
        pDstCrn += copylen;
    }

    for (; pSrcCrn < pSrcEnd;) {
        token = (int)*pSrcCrn++;
        copylen = token >> 4;
        if (copylen == 15) {
            for (tmp = (int)*pSrcCrn++; tmp == 255; tmp = (int)*pSrcCrn++) {
                copylen += 255;
            }
            copylen += tmp;
        }
    jmp1:
        if ((pDstCrn + copylen) > (pDstEnd)) goto jmperror;
        if ((pSrcCrn + copylen) > (pSrcEnd)) goto jmperror;
        #pragma ivdep
        for (tmp = 0; tmp < copylen; tmp++)
            pDstCrn[tmp] = pSrcCrn[tmp];
        pSrcCrn += copylen;
        pDstCrn += copylen;
        if (pSrcCrn >= pSrcEnd) break;
        offset = (int)*(Ipp16u *)pSrcCrn;
        pSrcCrn += 2;
        copylen = token & 0xf;
        pMatch = pDstCrn - offset;
        if (copylen == 15) {
            for (tmp = (int)*pSrcCrn++; tmp == 255; tmp = (int)*pSrcCrn++)
                copylen += 255;
            copylen += tmp;
        }
        copylen += 4;
    jmp2:
        if ((pDstCrn + copylen) > (pDstEnd)) goto jmperror;
        for (tmp = 0; tmp < copylen; tmp++)
            pDstCrn[tmp] = pDstCrn[tmp-offset];
        pDstCrn += copylen;
    }

    *pDstLen = (int)(pDstCrn - pDst);
    return ippStsNoErr;
jmperror:
    *pDstLen = -1;
    return ippStsMemAllocErr;
}
