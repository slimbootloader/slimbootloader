/*
// INTEL CONFIDENTIAL
// Copyright 2006 2015 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//   Purpose: Encoding bzip2-compatible functions
// 
//   Contents:
//       ownsHuffSelectGroup
// 
//   Author: Alexander Naduev
// 
// 
*/



#include "owndc.h"

#if (_IPP >= _IPP_W7) || (_IPP32E >= _IPP32E_M7)

    #define COST_ITERATION(N) cost128 = _mm_adds_epu16( cost128, *((__m128i*)pLengths128 + pSrcTmp[N]) )
    #define FREQ_ITERATION(N) pFreqsTmp[pSrcTmp[N]]++

/* Lib = W7, T7, V8, M7, U8 */
/* Caller = ippsEncodeHuffInit_BZ2_16u8u */
void ownsHuffSelectGroup( const Ipp16u* pSrc, int srcLen, int *pFreqs, Ipp8u* pLengths, int nGroups,
                          Ipp8u* pSelectors, int* pNSelectors )
{
    __declspec(align(16))
    __m128i pLengths128[258];
    __m128i cost128;
    Ipp16u  cost16[8];
    Ipp16u *pLengthsTmp;
    Ipp16u *pSrcTmp;
    int    *pFreqsTmp;
    int     i, j, idx, nSelectors;

    for ( i = 0; i < (nGroups * 258); i++ ) pFreqs[i] = 0;
    for ( i = 0, pLengthsTmp = (Ipp16u*)pLengths128; i < 258; i++, pLengthsTmp += 8 )
    {
        pLengthsTmp[0] = (Ipp16u)pLengths[i];           pLengthsTmp[1] = (Ipp16u)pLengths[i + 258];
        pLengthsTmp[2] = (Ipp16u)pLengths[i + 258 * 2]; pLengthsTmp[3] = (Ipp16u)pLengths[i + 258 * 3];
        pLengthsTmp[4] = (Ipp16u)pLengths[i + 258 * 4]; pLengthsTmp[5] = (Ipp16u)pLengths[i + 258 * 5];
    }
    for ( i = nSelectors = 0; i < srcLen - 49; i += 50 )
    {
        pSrcTmp = (Ipp16u*)pSrc + i;
        cost128 = _mm_setzero_si128();
        COST_ITERATION(0);  COST_ITERATION(1);  COST_ITERATION(2);  COST_ITERATION(3);  COST_ITERATION(4);
        COST_ITERATION(5);  COST_ITERATION(6);  COST_ITERATION(7);  COST_ITERATION(8);  COST_ITERATION(9);
        COST_ITERATION(10); COST_ITERATION(11); COST_ITERATION(12); COST_ITERATION(13); COST_ITERATION(14);
        COST_ITERATION(15); COST_ITERATION(16); COST_ITERATION(17); COST_ITERATION(18); COST_ITERATION(19);
        COST_ITERATION(20); COST_ITERATION(21); COST_ITERATION(22); COST_ITERATION(23); COST_ITERATION(24);
        COST_ITERATION(25); COST_ITERATION(26); COST_ITERATION(27); COST_ITERATION(28); COST_ITERATION(29);
        COST_ITERATION(30); COST_ITERATION(31); COST_ITERATION(32); COST_ITERATION(33); COST_ITERATION(34);
        COST_ITERATION(35); COST_ITERATION(36); COST_ITERATION(37); COST_ITERATION(38); COST_ITERATION(39);
        COST_ITERATION(40); COST_ITERATION(41); COST_ITERATION(42); COST_ITERATION(43); COST_ITERATION(44);
        COST_ITERATION(45); COST_ITERATION(46); COST_ITERATION(47); COST_ITERATION(48); COST_ITERATION(49);
        _mm_storeu_si128( (__m128i*)cost16, cost128 );
        for ( j = 1, idx = 0; j < nGroups; j++ ) idx = (cost16[idx] <= cost16[j]) ? idx : j;
        pFreqsTmp                = pFreqs + idx * 258;
        pSelectors[nSelectors++] = (Ipp8u)idx;
        FREQ_ITERATION(0);  FREQ_ITERATION(1);  FREQ_ITERATION(2);  FREQ_ITERATION(3);  FREQ_ITERATION(4);
        FREQ_ITERATION(5);  FREQ_ITERATION(6);  FREQ_ITERATION(7);  FREQ_ITERATION(8);  FREQ_ITERATION(9);
        FREQ_ITERATION(10); FREQ_ITERATION(11); FREQ_ITERATION(12); FREQ_ITERATION(13); FREQ_ITERATION(14);
        FREQ_ITERATION(15); FREQ_ITERATION(16); FREQ_ITERATION(17); FREQ_ITERATION(18); FREQ_ITERATION(19);
        FREQ_ITERATION(20); FREQ_ITERATION(21); FREQ_ITERATION(22); FREQ_ITERATION(23); FREQ_ITERATION(24);
        FREQ_ITERATION(25); FREQ_ITERATION(26); FREQ_ITERATION(27); FREQ_ITERATION(28); FREQ_ITERATION(29);
        FREQ_ITERATION(30); FREQ_ITERATION(31); FREQ_ITERATION(32); FREQ_ITERATION(33); FREQ_ITERATION(34);
        FREQ_ITERATION(35); FREQ_ITERATION(36); FREQ_ITERATION(37); FREQ_ITERATION(38); FREQ_ITERATION(39);
        FREQ_ITERATION(40); FREQ_ITERATION(41); FREQ_ITERATION(42); FREQ_ITERATION(43); FREQ_ITERATION(44);
        FREQ_ITERATION(45); FREQ_ITERATION(46); FREQ_ITERATION(47); FREQ_ITERATION(48); FREQ_ITERATION(49);
    }
    if ( i < srcLen )
    {
        pSrcTmp = (Ipp16u*)pSrc;
        cost128 = _mm_setzero_si128();
        for ( j = i; j < srcLen; j++ ) COST_ITERATION(j);
        _mm_storeu_si128( (__m128i*)cost16, cost128 );
        for ( j = 1, idx = 0; j < nGroups; j++ ) idx = (cost16[idx] <= cost16[j]) ? idx : j;
        pFreqsTmp                = pFreqs + idx * 258;
        pSelectors[nSelectors++] = (Ipp8u)idx;
        for ( ; i < srcLen; i++ ) FREQ_ITERATION(i);
    }
    *pNSelectors = nSelectors;
} /* ownsHuffSelectGroup */

#endif

