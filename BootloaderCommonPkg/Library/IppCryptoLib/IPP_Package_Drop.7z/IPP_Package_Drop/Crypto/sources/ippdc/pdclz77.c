/*
// INTEL CONFIDENTIAL
// Copyright 2004 2015 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//   Purpose: Functions for supporting rfc1950, rfc1951, rfc1952
// 
//   Contents:
// 
//       ippsAdler32_8u
//       ippsCRC32_8u
// 
//   Authors: Evgeny Kravtsounov, Alexander Naduev, Gregory Ulkin, Ivan Zavarzin, Sergey Khlystov
// 
// 
*/


//#include "owndc.h"
#include "owns.h"
#include "pdc_anadler32.h"
#include "pdc_ancrc32.h"
#include "pscopy.h"

#define ADLB 65521
#define ADLNM 5552

#define ADL1(buf,i)  {s1 += buf[i]; s2 += s1;}
#define ADL2(buf,i)  ADL1(buf,i); ADL1(buf,i+1);
#define ADL4(buf,i)  ADL2(buf,i); ADL2(buf,i+2);
#define ADL8(buf,i)  ADL4(buf,i); ADL4(buf,i+4);
#define ADL16(buf)   ADL8(buf,0); ADL8(buf,8);

#define ADLMOD(a) \
    do { \
        if (a >= (ADLB << 16)) a -= (ADLB << 16); \
        if (a >= (ADLB << 15)) a -= (ADLB << 15); \
        if (a >= (ADLB << 14)) a -= (ADLB << 14); \
        if (a >= (ADLB << 13)) a -= (ADLB << 13); \
        if (a >= (ADLB << 12)) a -= (ADLB << 12); \
        if (a >= (ADLB << 11)) a -= (ADLB << 11); \
        if (a >= (ADLB << 10)) a -= (ADLB << 10); \
        if (a >= (ADLB << 9)) a -= (ADLB << 9); \
        if (a >= (ADLB << 8)) a -= (ADLB << 8); \
        if (a >= (ADLB << 7)) a -= (ADLB << 7); \
        if (a >= (ADLB << 6)) a -= (ADLB << 6); \
        if (a >= (ADLB << 5)) a -= (ADLB << 5); \
        if (a >= (ADLB << 4)) a -= (ADLB << 4); \
        if (a >= (ADLB << 3)) a -= (ADLB << 3); \
        if (a >= (ADLB << 2)) a -= (ADLB << 2); \
        if (a >= (ADLB << 1)) a -= (ADLB << 1); \
        if (a >= ADLB) a -= ADLB; \
    } while (0)


/**********************************************************************************/

IPPFUN( IppStatus, ippsAdler32_8u, (const Ipp8u* pSrc, int srcLen, Ipp32u* pAdler32) )
{
    IPP_BAD_PTR1_RET(pAdler32);
    if ( pSrc == 0 )
    {
        *pAdler32 = 1;
        return ippStsNoErr;
    }

#if (_IPP >= _IPP_W7) || (_IPP32E >= _IPP32E_M7) || (_IPPLRB > _IPPLRB_PX)

    ownsAdler32_8u( pSrc, srcLen, pAdler32 );

#else

    {
        Ipp32u s1 = (*(pAdler32)) & 0xffff;
        Ipp32u s2 = ( (*(pAdler32)) >> 16) & 0xffff;
        int k;
        while (srcLen > 0)
        {
            k = srcLen < ADLNM ? (int)srcLen : ADLNM;
            srcLen -= k;
            while (k >= 16)
            {
                ADL16(pSrc);
                pSrc += 16;
                k -= 16;
            }
            if (k != 0) do
                {
                    s1 += *pSrc++;
                    s2 += s1;
                } while (--k);
            ADLMOD(s1);
            ADLMOD(s2);
        }
        (*(pAdler32)) = (s2 << 16) | s1;
    }

#endif

    return ippStsNoErr;
} /* ippsAdler32_8u() */

/************************************************************************************************/

IPPFUN( IppStatus, ippsCRC32_8u, (const Ipp8u* pSrc, int srcLen, Ipp32u* pCRC32) )
{

    IPP_BAD_PTR2_RET(pSrc, pCRC32);
    IPP_BAD_SIZE_RET(srcLen);
    {

#if (IPP_ENDIAN == IPP_LITTLE_ENDIAN)

#if ( _IPP >= _IPP_P8 ) || ( _IPP32E >= _IPP32E_Y8 )

        if ( ownGetFeature( ippCPUID_CLMUL ) )
        {
            *pCRC32 = owns_zlib_reduction_crc_proc( pSrc, srcLen, *pCRC32 );
        }
        else

#endif

            ownsCRC32_8u( pSrc, srcLen, pCRC32 );

#else

        Ipp32u crc32;
        int i;

        crc32 = *pCRC32;
        crc32 = crc32 ^ 0xffffffff;
        for ( i = 0; i < srcLen; i++ )
        {
            crc32 = crcTab[((int)crc32 ^ (int)pSrc[i]) & 0xff] ^ (crc32 >> 8);
        }
        *pCRC32 = crc32 ^ 0xffffffff;

#endif

    }
    return ippStsNoErr;
} /* ippsCRC32_8u */

/************************************************************************************************/

