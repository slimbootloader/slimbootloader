/*
// INTEL CONFIDENTIAL
// Copyright 1999 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//   VSS:
//       $Workfile: $
//       $Revision: 7753 $
//       $Date$
// 
//   2001/11/03
// 
//   Purpose:    Copying a vector into second vector (Copy).
//               Filling a vector by 0               (Zero).
//               Filling a vector by value           (Set).
// 
//   Contents:   ownsCopy_8u
//               ownsZero_8u
//               ownsSet_8u
//               ownsSet_16u
//               ownsSet_32s
//               ownsSet_64s
//               ownsSet_64sc
//               ownsPrefetchCopy_8u_A6
//               ownsCopy_8u_A6
//               ownsZero_8u_A6
//               ownsSet_8u_A6
//               ownsSet_32s_A6
//               ownsSet_16u_A6
//               ownsSet_64s_A6
//               ownsSet_64sc_A6
//               ownsPrefetcht0_A6
//               ownsPrefetchnta_A6
// 
//   Author: Arkady Solncev
// 
// 
*/


#if !defined (__PSCOPY_H__)
#define __PSCOPY_H__

/***********************************************************/
/************************** Copy ***************************/
/***********************************************************/
#define ownsCopy_8s(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp8s))

#define ownsCopy_8sc(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp8sc))

#define ownsCopy_16u(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp16u))

#define ownsCopy_16s(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp16s))

#define ownsCopy_16sc(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp16sc))

#define ownsCopy_32u(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32u))

#define ownsCopy_32s(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32s))

#define ownsCopy_32sc(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32sc))

#define ownsCopy_32f(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32f))

#define ownsCopy_32fc(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32fc))

#define ownsCopy_64s(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64s))

#define ownsCopy_64sc(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64sc))

#define ownsCopy_64f(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64f))

#define ownsCopy_64fc(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64fc))

#if defined (_A6)
/*===========================================================
The instruction movntq is applied.
*/
#define ownsCopy_8s_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp8s))

#define ownsCopy_8sc_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp8sc))

#define ownsCopy_16u_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp16u))

#define ownsCopy_16s_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp16s))

#define ownsCopy_16sc_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp16sc))

#define ownsCopy_32u_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32u))

#define ownsCopy_32s_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32s))

#define ownsCopy_32sc_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32sc))

#define ownsCopy_32f_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32f))

#define ownsCopy_32fc_A6(S,D,L) \
   ownsCopy_8u((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32fc))

#define ownsCopy_64s_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64s))

#define ownsCopy_64sc_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64sc))

#define ownsCopy_64f_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64f))

#define ownsCopy_64fc_A6(S,D,L) \
   ownsCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64fc))

/*====================================================================
Purpose: To organize copying of a vector by parts on 4KB ("Hack").
Note: The functions ownsPrefetchnta_A6 and ownsCopy_8u_A6  are used.
*/
#define ownsPrefetchCopy_8s_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp8s))

#define ownsPrefetchCopy_8sc_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp8sc))

#define ownsPrefetchCopy_16u_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp16u))

#define ownsPrefetchCopy_16s_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp16s))

#define ownsPrefetchCopy_16sc_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp16sc))

#define ownsPrefetchCopy_32u_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32u))

#define ownsPrefetchCopy_32s_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32s))

#define ownsPrefetchCopy_32sc_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32sc))

#define ownsPrefetchCopy_32f_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32f))

#define ownsPrefetchCopy_32fc_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp32fc))

#define ownsPrefetchCopy_64s_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64s))

#define ownsPrefetchCopy_64sc_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64sc))

#define ownsPrefetchCopy_64f_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64f))

#define ownsPrefetchCopy_64fc_A6(S,D,L) \
   ownsPrefetchCopy_8u_A6((Ipp8u*)(S),(Ipp8u*)(D),(L)*sizeof(Ipp64fc))
#endif

/***********************************************************/
/************************** Zero ***************************/
/***********************************************************/
#define ownsZero_8s(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp8s))

#define ownsZero_8sc(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp8sc))

#define ownsZero_16u(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp16u))

#define ownsZero_16s(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp16s))

#define ownsZero_16sc(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp16sc))

#define ownsZero_32u(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp32u))

#define ownsZero_32s(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp32s))

#define ownsZero_32sc(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp32sc))

#define ownsZero_32f(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp32f))

#define ownsZero_32fc(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp32fc))

#define ownsZero_64s(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp64s))

#define ownsZero_64sc(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp64sc))

#define ownsZero_64f(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp64f))

#define ownsZero_64fc(D,L) \
   ownsZero_8u((Ipp8u*)(D),(L)*sizeof(Ipp64fc))

#if defined (_A6)
/*==============================================
The instruction movntq is applied.
*/
#define ownsZero_8s_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp8s))

#define ownsZero_8sc_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp8sc))

#define ownsZero_16u_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp16u))

#define ownsZero_16s_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp16s))

#define ownsZero_16sc_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp16sc))

#define ownsZero_32u_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp32u))

#define ownsZero_32s_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp32s))

#define ownsZero_32sc_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp32sc))

#define ownsZero_32f_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp32f))

#define ownsZero_32fc_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp32fc))

#define ownsZero_64s_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp64s))

#define ownsZero_64sc_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp64sc))

#define ownsZero_64f_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp64f))

#define ownsZero_64fc_A6(D,L) \
   ownsZero_8u_A6((Ipp8u*)(D),(L)*sizeof(Ipp64fc))
#endif

/*==============================================================================
With such names there are same versions of these functions:
   1). Version for _PX ("C").
   2). Versions for _M6 and is higher (asm).
*/
extern Ipp8u* ownsCopy_8u( const Ipp8u* pSrc, Ipp8u* pDst, int len );
extern Ipp8u* ownsZero_8u( Ipp8u* pDst, int len );
extern Ipp8u* ownsSet_8u( Ipp8u val, Ipp8u* pDst, int len);
extern Ipp16u* ownsSet_16u( Ipp16u val, Ipp16u* pDst, int len);
extern Ipp32s* ownsSet_32s( Ipp32s val, Ipp32s* pDst, int len);
extern Ipp64s* ownsSet_64s( Ipp64s val, Ipp64s* pDst, int len);
extern Ipp64sc* ownsSet_64sc( Ipp64sc val, Ipp64sc* pDst, int len);

#if defined (_A6)
/*==============================================================================
Purpose: To organize copying of a vector by parts on 4KB ("Hack").
Note: The functions ownsPrefetchnta_A6 and ownsCopy_8u_A6  are used.
*/
extern Ipp8u* ownsPrefetchCopy_8u_A6( const Ipp8u *pSrc, Ipp8u *pDst, int len );

/*==============================================================================
The instruction movntq is applied.
*/
extern Ipp8u* ownsCopy_8u_A6( const Ipp8u* pSrc, Ipp8u* pDst, int len );
extern Ipp8u* ownsZero_8u_A6( Ipp8u* pDst, int len );
extern Ipp8u* ownsSet_8u_A6( Ipp8u val, Ipp8u* pDst, int len);
extern Ipp16u* ownsSet_16u_A6( Ipp16u val, Ipp16u* dst, int len);
extern Ipp32s* ownsSet_32s_A6( Ipp32s val, Ipp32s* dst, int len);
extern Ipp64s* ownsSet_64s_A6( Ipp64s val, Ipp64s* dst, int len);
extern Ipp64sc* ownsSet_64sc_A6( Ipp64sc val, Ipp64sc* dst, int len);

/*============================================================
Purpose: loading of a vector in cache.
    1). The availability of addresses in TLB is ensured.
    2). If length of a vector is more the cache,
        in the cache there will be a higher part of a vector
*/
extern void ownsPrefetcht0_A6(const Ipp8u *pSrc, int len);
extern void ownsPrefetchnta_A6(const Ipp8u *pSrc, int len);
#endif

/*******************************************************************************/

#endif /* #if !defined (__PSCOPY_H__) */
