/*
// INTEL CONFIDENTIAL
// Copyright 2008 2017 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//  Created: Wednesday, August 13, 2008 06:06:52 by asolntse
// 
// 
*/



#ifndef __OWNS_H__
#include "owncore.h"
#endif

#ifndef __CPUDEF_H__
#include "cpudef.h"
#endif

#include "dispatcher.h"

static Ipp64u ownFeatures = 0;
static Ipp32u ownFeaturesAreValid = 0;
static Ipp64u ownFeaturesMask = PX_FM;

#define BIT00 0x00000001
#define BIT01 0x00000002
#define BIT02 0x00000004
#define BIT03 0x00000008
#define BIT04 0x00000010
#define BIT05 0x00000020
#define BIT06 0x00000040
#define BIT07 0x00000080
#define BIT08 0x00000100
#define BIT09 0x00000200
#define BIT10 0x00000400
#define BIT11 0x00000800
#define BIT12 0x00001000
#define BIT13 0x00002000
#define BIT14 0x00004000
#define BIT15 0x00008000
#define BIT16 0x00010000
#define BIT17 0x00020000
#define BIT18 0x00040000
#define BIT19 0x00080000
#define BIT20 0x00100000
#define BIT21 0x00200000
#define BIT22 0x00400000
#define BIT23 0x00800000
#define BIT24 0x01000000
#define BIT25 0x02000000
#define BIT26 0x04000000
#define BIT27 0x08000000
#define BIT28 0x10000000
#define BIT29 0x20000000
#define BIT30 0x40000000
#define BIT31 0x80000000

/*===================================================================*/
int ownGetMaskFeatures( Ipp64u* pFeaturesMask )
{
  Ipp32u  buf[4];
  Ipp32u  eax_, ebx_, ecx_, edx_, tmp;
  Ipp64u  mask;
  int flgFMA=0, flgINT=0, flgGPR=0;// avx2

    if( !ownFeaturesAreValid ) {
      if( !(ipp_has_cpuid()) ) {
        return ownFeaturesAreValid;
      } else {
        Ipp32u idBaseMax, idExtdMax;
        ownGetReg((int*)buf, 0, 0);//get max value for basic info.
        idBaseMax = buf[0];
        ownGetReg((int*)buf, 0x80000000, 0);//get max value for extended info.
        idExtdMax = buf[0];

        ownGetReg( (int*)buf, 1, 0 );
        eax_ = (Ipp32u)buf[0];
        ecx_ = (Ipp32u)buf[2];
        edx_ = (Ipp32u)buf[3];
        mask = 0;
        if( edx_ & BIT23 ) mask |= ippCPUID_MMX;          // edx[23] - MMX (P2)
        if( edx_ & BIT25 ) mask |= ippCPUID_SSE;          // edx[25] - SSE (P3)
        if( edx_ & BIT26 ) mask |= ippCPUID_SSE2;         // edx[26] - SSE2 (P4)
        if( ecx_ & BIT00 ) mask |= ippCPUID_SSE3;         // ecx[0]  - SSE3 (Prescott)
        if( ecx_ & BIT09 ) mask |= ippCPUID_SSSE3;        // ecx[9]  - SSSE3 (Merom)
        if( ecx_ & BIT22 ) mask |= ippCPUID_MOVBE;        // ecx[22] - MOVBE (Atom #1)
        if( ecx_ & BIT19 ) mask |= ippCPUID_SSE41;        // ecx[19] - SSE4.1 (Penryn)
        if( ecx_ & BIT20 ) mask |= ippCPUID_SSE42;        // ecx[20] - SSE4.2 (Nenalem)
        if( ecx_ & BIT28 ) mask |= ippCPUID_AVX;          // ecx[28] - AVX (SNB)
        if(( ecx_ & 0x18000000 ) == 0x18000000 ){
            tmp = (Ipp32u)ipp_is_avx_extension();
            if( tmp & BIT00 ) mask |= ippAVX_ENABLEDBYOS; // AVX is supported by OS
        }
        if( ecx_ & BIT25 ) mask |= ippCPUID_AES;          // ecx[25] - AES instruction
        if( ecx_ & BIT01 ) mask |= ippCPUID_CLMUL;        // ecx[1]  - PCLMULQDQ instruction
        if( ecx_ & BIT30 ) mask |= ippCPUID_RDRAND;       // ecx[30] - RDRRAND instruction
        if( ecx_ & BIT29 ) mask |= ippCPUID_F16C;         // ecx[29] - Float16 instructions
             // AVX2 instructions extention: only if 3 features are enabled at once:
             // FMA, AVX-256 int & GPR BMI (bit-manipulation);
        if( ecx_ & BIT12 ) flgFMA = 1; else flgFMA = 0;   // ecx[12] - FMA 128 & 256 bit
        if( idBaseMax >= 7 ){                             // get CPUID.eax = 7
           ownGetReg( (int*)buf, 0x7, 0 );
           ebx_ = (Ipp32u)buf[1];
           ecx_ = (Ipp32u)buf[2];
           edx_ = (Ipp32u)buf[3];
           if( ebx_ & BIT05 ) flgINT = 1;
           else flgINT = 0;                               //ebx[5], AVX2 (int 256bits)
               // ebx[3] - enabled ANDN, BEXTR, BLSI, BLSMK, BLSR, TZCNT
               // ebx[8] - enabled BZHI, MULX, PDEP, PEXT, RORX, SARX, SHLX, SHRX
           if(( ebx_ & BIT03 )&&( ebx_ & BIT08 )) flgGPR = 1; 
           else flgGPR = 0;                               // VEX-encoded GPR instructions (GPR BMI)
               // BDW instructions extention
           if( ebx_ & BIT19 ) mask |= ippCPUID_ADCOX;     // eax[0x7] -->> ebx:: Bit 19: ADX
           if( ebx_ & BIT18 ) mask |= ippCPUID_RDSEED;    // eax[0x7] -->> ebx:: Bit 18: RDSEED
           if( ebx_ & BIT29 ) mask |= ippCPUID_SHA;       // eax[0x7] -->> ebx:: Bit 29: SHA
               // AVX512 instructions extention
           if(ipp_is_avx512_extension()){
                              mask |= ippAVX512_ENABLEDBYOS; // AVX-512 is supported by OS
           }
           if( ebx_ & BIT16 ) mask |= ippCPUID_AVX512F;   // ebx[16] - AVX-512 Foundation
           if( ebx_ & BIT26 ) mask |= ippCPUID_AVX512PF;  // ebx[26] - AVX-512 Prefetch instructions
           if( ebx_ & BIT27 ) mask |= ippCPUID_AVX512ER;  // ebx[27] - AVX-512 Exponential and Reciprocal instructions
           if( ebx_ & BIT28 ) mask |= ippCPUID_AVX512CD;  // ebx[28] - AVX-512 Conflict Detection
           if( ebx_ & BIT17 ) mask |= ippCPUID_AVX512DQ;  // ebx[17] - AVX-512 Dword & Quadword
           if( ebx_ & BIT30 ) mask |= ippCPUID_AVX512BW;  // ebx[30] - AVX-512 Byte & Word
           if( ebx_ & BIT31 ) mask |= ippCPUID_AVX512VL;  // ebx[31] - AVX-512 Vector Length extensions
           if( ecx_ & BIT01 ) mask |= ippCPUID_AVX512VBMI; // ecx[01] - AVX-512 Vector Byte Manipulation Instructions
           if( edx_ & BIT02 ) mask |= ippCPUID_AVX512_4VNNIW; // edx[02] - AVX-512 Vector instructions for deep learning enhanced word variable precision
           if( edx_ & BIT03 ) mask |= ippCPUID_AVX512_4FMADDPS; // edx[03] - AVX-512 Vector instructions for deep learning floating-point single precision
               // MPX: bitwise OR between ippCPUID_MPX & ippCPUID_AVX flags can be used to define that arch is GE than Skylake
           if( ebx_ & BIT14 ) mask |= ippCPUID_MPX;       // ebx[14] - Intel MPX (Memory Protection Extensions)
           if (ebx_ & BIT21) mask |= ippCPUID_AVX512IFMA;  // ebx[21] - AVX-512IFMA PMADD52
        }
        mask = ( flgFMA && flgINT && flgGPR ) ? (mask | ippCPUID_AVX2) : mask; // to separate AVX2 flags here

        if( idExtdMax >= 0x80000001 ){ // get CPUID.eax=0x80000001
           ownGetReg( (int*)buf, 0x80000001, 0 );
           ecx_ = (Ipp32u)buf[2];
               // BDW instructions extention
           if( ecx_ & BIT08 ) mask |= ippCPUID_PREFETCHW; // eax[0x80000001] -->> ecx:: Bit 8: PREFETCHW
        }
            // Knights Corner
        if(((( eax_ << 20 ) >> 24 ) ^ 0xb1 ) == 0 ){
            mask = mask | ippCPUID_KNC;
        }
        ownFeatures = mask;
        ownFeaturesAreValid = 1;
      }
    }
    *pFeaturesMask = ownFeatures;
    return ownFeaturesAreValid;
}

/*=======================================================================*/
/*
1). The "ownFeatures" is initialized by ippCpuFeatures.
2). Features mask (MaskOfFeature) values are defined in the ippdefs.h:
    ippCPUID_MMX        0x00000001   Intel Architecture MMX technology supported
    ippCPUID_SSE        0x00000002   Streaming SIMD Extensions
    ippCPUID_SSE2       0x00000004   Streaming SIMD Extensions 2
    ippCPUID_SSE3       0x00000008   Streaming SIMD Extensions 3
    ippCPUID_SSSE3      0x00000010   Supplemental Streaming SIMD Extensions 3
    ippCPUID_MOVBE      0x00000020   The processor supports MOVBE instruction
    ippCPUID_SSE41      0x00000040   Streaming SIMD Extensions 4.1
    ippCPUID_SSE42      0x00000080   Streaming SIMD Extensions 4.2
    ippCPUID_AVX        0x00000100   Advanced Vector Extensions instruction set
    ippAVX_ENABLEDBYOS  0x00000200   The operating system supports AVX
    ippCPUID_AES        0x00000400   AES instruction
    ippCPUID_CLMUL      0x00000800   PCLMULQDQ instruction
    ippCPUID_ABR        0x00001000   Aubrey Isle
    ippCPUID_RDRAND     0x00002000   RDRRAND instruction
    ippCPUID_F16C       0x00004000   Float16 instructions
    ippCPUID_AVX2       0x00008000   AVX2
    ippCPUID_ADCOX      0x00010000   ADCX and ADOX instructions
    ippCPUID_RDSEED     0x00020000   the RDSEED instruction
    ippCPUID_PREFETCHW  0x00040000   PREFETCHW
    ippCPUID_SHA        0x00080000   Intel (R) SHA Extensions
    ippCPUID_KNC        0x80000000   Knights Corner instruction set

//#define   ippCPUID_AVX2_FMA   0x0008000    256bits fused-multiply-add instructions set
//#define   ippCPUID_AVX2_INT   0x0010000    256bits integer instructions set
//#define   ippCPUID_AVX2_GPR   0x0020000    VEX-encoded general-purpose instructions set
*/
/*=======================================================================*/
int __CDECL ownGetFeature( Ipp64u MaskOfFeature )
{
  if( (ownFeaturesMask & MaskOfFeature) == MaskOfFeature ) {
    return 1;
  } else {
    return 0;
  };
}

int ownSetFeatureMask( Ipp64u ippFeatureMask ){
  ownFeaturesMask = ippFeatureMask;
  return 1;
}

IPPFUN( Ipp64u, ippGetEnabledCpuFeatures, ( void ) )
{
  return ownFeaturesMask;
}

void ownMaskIsFeatures(void)
{
    ownFeatures = ownFeaturesMask;
    ownFeaturesAreValid = 1;
}

