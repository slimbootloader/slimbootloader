/*
// INTEL CONFIDENTIAL
// Copyright 2008 2015 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//   Purpose: Functions for computing the CRC32C (the polinomial
//            0x11EDC6F41) value for the source vector.
// 
//       Reference: "Optimization of cyclic redundancy-check codes with 24
//       and 32 parity bits". Castagnoli, G.; Brauer, S.; Herrmann, M.;
//       Communications, IEEE Transactions on Volume 41, Issue 6, June 1993
//       Page(s):883 - 892.
//       doi:10.1109/DSN.2002.1028931,
//       http:ieeexplore.ieee.org/search/wrapper.jsp?arnumber=231911
// 
//   Contents:
//       ippsCRC32C_8u
// 
//   Authors: Alexander Naduev
// 
// 
*/


#include "owndc.h"
#include "pdc_ancrc32.h"

#if (IPP_ENDIAN == IPP_BIG_ENDIAN)

static const Ipp32u CRC32CTable[256] = {
    {
        0x00000000, 0x03836BF2, 0xF7703BE1, 0xF4F35013, 0x1F979AC7,
        0x1C14F135, 0xE8E7A126, 0xEB64CAD4, 0xCF58D98A, 0xCCDBB278,
        0x3828E26B, 0x3BAB8999, 0xD0CF434D, 0xD34C28BF, 0x27BF78AC,
        0x243C135E, 0x6FC75E10, 0x6C4435E2, 0x98B765F1, 0x9B340E03,
        0x7050C4D7, 0x73D3AF25, 0x8720FF36, 0x84A394C4, 0xA09F879A,
        0xA31CEC68, 0x57EFBC7B, 0x546CD789, 0xBF081D5D, 0xBC8B76AF,
        0x487826BC, 0x4BFB4D4E, 0xDE8EBD20, 0xDD0DD6D2, 0x29FE86C1,
        0x2A7DED33, 0xC11927E7, 0xC29A4C15, 0x36691C06, 0x35EA77F4,
        0x11D664AA, 0x12550F58, 0xE6A65F4B, 0xE52534B9, 0x0E41FE6D,
        0x0DC2959F, 0xF931C58C, 0xFAB2AE7E, 0xB149E330, 0xB2CA88C2,
        0x4639D8D1, 0x45BAB323, 0xAEDE79F7, 0xAD5D1205, 0x59AE4216,
        0x5A2D29E4, 0x7E113ABA, 0x7D925148, 0x8961015B, 0x8AE26AA9,
        0x6186A07D, 0x6205CB8F, 0x96F69B9C, 0x9575F06E, 0xBC1D7B41,
        0xBF9E10B3, 0x4B6D40A0, 0x48EE2B52, 0xA38AE186, 0xA0098A74,
        0x54FADA67, 0x5779B195, 0x7345A2CB, 0x70C6C939, 0x8435992A,
        0x87B6F2D8, 0x6CD2380C, 0x6F5153FE, 0x9BA203ED, 0x9821681F,
        0xD3DA2551, 0xD0594EA3, 0x24AA1EB0, 0x27297542, 0xCC4DBF96,
        0xCFCED464, 0x3B3D8477, 0x38BEEF85, 0x1C82FCDB, 0x1F019729,
        0xEBF2C73A, 0xE871ACC8, 0x0315661C, 0x00960DEE, 0xF4655DFD,
        0xF7E6360F, 0x6293C661, 0x6110AD93, 0x95E3FD80, 0x96609672,
        0x7D045CA6, 0x7E873754, 0x8A746747, 0x89F70CB5, 0xADCB1FEB,
        0xAE487419, 0x5ABB240A, 0x59384FF8, 0xB25C852C, 0xB1DFEEDE,
        0x452CBECD, 0x46AFD53F, 0x0D549871, 0x0ED7F383, 0xFA24A390,
        0xF9A7C862, 0x12C302B6, 0x11406944, 0xE5B33957, 0xE63052A5,
        0xC20C41FB, 0xC18F2A09, 0x357C7A1A, 0x36FF11E8, 0xDD9BDB3C,
        0xDE18B0CE, 0x2AEBE0DD, 0x29688B2F, 0x783BF682, 0x7BB89D70,
        0x8F4BCD63, 0x8CC8A691, 0x67AC6C45, 0x642F07B7, 0x90DC57A4,
        0x935F3C56, 0xB7632F08, 0xB4E044FA, 0x401314E9, 0x43907F1B,
        0xA8F4B5CF, 0xAB77DE3D, 0x5F848E2E, 0x5C07E5DC, 0x17FCA892,
        0x147FC360, 0xE08C9373, 0xE30FF881, 0x086B3255, 0x0BE859A7,
        0xFF1B09B4, 0xFC986246, 0xD8A47118, 0xDB271AEA, 0x2FD44AF9,
        0x2C57210B, 0xC733EBDF, 0xC4B0802D, 0x3043D03E, 0x33C0BBCC,
        0xA6B54BA2, 0xA5362050, 0x51C57043, 0x52461BB1, 0xB922D165,
        0xBAA1BA97, 0x4E52EA84, 0x4DD18176, 0x69ED9228, 0x6A6EF9DA,
        0x9E9DA9C9, 0x9D1EC23B, 0x767A08EF, 0x75F9631D, 0x810A330E,
        0x828958FC, 0xC97215B2, 0xCAF17E40, 0x3E022E53, 0x3D8145A1,
        0xD6E58F75, 0xD566E487, 0x2195B494, 0x2216DF66, 0x062ACC38,
        0x05A9A7CA, 0xF15AF7D9, 0xF2D99C2B, 0x19BD56FF, 0x1A3E3D0D,
        0xEECD6D1E, 0xED4E06EC, 0xC4268DC3, 0xC7A5E631, 0x3356B622,
        0x30D5DDD0, 0xDBB11704, 0xD8327CF6, 0x2CC12CE5, 0x2F424717,
        0x0B7E5449, 0x08FD3FBB, 0xFC0E6FA8, 0xFF8D045A, 0x14E9CE8E,
        0x176AA57C, 0xE399F56F, 0xE01A9E9D, 0xABE1D3D3, 0xA862B821,
        0x5C91E832, 0x5F1283C0, 0xB4764914, 0xB7F522E6, 0x430672F5,
        0x40851907, 0x64B90A59, 0x673A61AB, 0x93C931B8, 0x904A5A4A,
        0x7B2E909E, 0x78ADFB6C, 0x8C5EAB7F, 0x8FDDC08D, 0x1AA830E3,
        0x192B5B11, 0xEDD80B02, 0xEE5B60F0, 0x053FAA24, 0x06BCC1D6,
        0xF24F91C5, 0xF1CCFA37, 0xD5F0E969, 0xD673829B, 0x2280D288,
        0x2103B97A, 0xCA6773AE, 0xC9E4185C, 0x3D17484F, 0x3E9423BD,
        0x756F6EF3, 0x76EC0501, 0x821F5512, 0x819C3EE0, 0x6AF8F434,
        0x697B9FC6, 0x9D88CFD5, 0x9E0BA427, 0xBA37B779, 0xB9B4DC8B,
        0x4D478C98, 0x4EC4E76A, 0xA5A02DBE, 0xA623464C, 0x52D0165F,
        0x51537DAD
    }
};

    #define REV(x) ((((x)&0xff)<<24)|(((x)&0xff00)<<8)|(((x)>>8)&0xff00)|((x)>>24))

#endif

IPPFUN( IppStatus, ippsCRC32C_8u, (const Ipp8u* pSrc, Ipp32u srcLen, Ipp32u* pCRC32C) )
{

    IPP_BAD_PTR2_RET(pSrc, pCRC32C);
    IPP_BAD_SIZE_RET(srcLen);

#if (IPP_ENDIAN == IPP_LITTLE_ENDIAN)

    ownsCRC32C_8u( pSrc, srcLen, pCRC32C );

#else

    {
        Ipp32u CRC32C = REV(*pCRC32C);
        Ipp32u i;

        for ( i = 0; i < srcLen; i++ )
        {
            CRC32C = CRC32CTable[(CRC32C >> 24) ^ pSrc[i]] ^ (CRC32C << 8);
        }
        *pCRC32C = REV(CRC32C);
    }

#endif

    return ippStsNoErr;
} /* ippsCRC32C_8u */

