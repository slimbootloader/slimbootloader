/*
// INTEL CONFIDENTIAL
// Copyright 2004 2015 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//   Purpose: Functions of the Move To Front transform
// 
//   Contents:
//       ippsMTFInit_8u
//       ippsMTFGetSize_8u
//       ippsMTFFwd_8u
//       ippsMTFInv_8u
// 
//   Author: Alexander Naduev
// 
// 
*/



#include "owndc.h"
#include "pdc_anmtf.h"

struct MTFState_8u
{
    Ipp8u heap[256]; // heap of symbols
};

IPPFUN(IppStatus, ippsMTFGetSize_8u, ( int* pMTFStateSize ))
{
    IPP_BAD_PTR1_RET(pMTFStateSize);
    *pMTFStateSize = sizeof(IppMTFState_8u);
    return ippStsNoErr;
} /* ippsMTFGetSize_8u */

IPPFUN(IppStatus, ippsMTFInit_8u, ( IppMTFState_8u* pMTFState ))
{
    IPP_BAD_PTR1_RET(pMTFState);
    {
        Ipp8u *heap = pMTFState->heap;
        int    i;

        for ( i = 0; i < 256; i++ )
        {
            heap[i] = (Ipp8u)i;
        }
    }
    return ippStsNoErr;
} /* ippsMTFInit_8u */

IPPFUN(IppStatus, ippsMTFFwd_8u, ( const Ipp8u* pSrc, Ipp8u* pDst, int len, IppMTFState_8u* pMTFState ))
{
    IPP_BAD_PTR3_RET(pSrc, pDst, pMTFState);
    IPP_BAD_SIZE_RET(len);

#if (_IPP >= _IPP_W7) || (_IPP32E >= _IPP32E_M7) || (_IPPLRB > _IPPLRB_PX)

    ownsMTFFwd_8u( pSrc, pDst, len, pMTFState->heap );

#else

    {
        Ipp8u *heap = pMTFState->heap;
        int   i, j;
        Ipp8u tmpCh;

        for ( i = 0; i < len; i++ )
        {
            tmpCh = pSrc[i];
            for ( j = 0; (j < 256) && (tmpCh != heap[j]); j++ );
            if ( j )
            {
                ippsMove_8u( heap, heap + 1, j );
                *heap = tmpCh;
            }
            pDst[i] = (Ipp8u)j;
        }
    }

#endif

    return ippStsNoErr;
} /* ippsMTFFwd_8u */

IPPFUN(IppStatus, ippsMTFInv_8u, ( const Ipp8u* pSrc, Ipp8u* pDst, int len, IppMTFState_8u* pMTFState ))
{
    IPP_BAD_PTR3_RET(pSrc, pDst, pMTFState);
    IPP_BAD_SIZE_RET(len);

#if (_IPP >= _IPP_W7) || (_IPP32E >= _IPP32E_M7) || (_IPPLRB > _IPPLRB_PX)

    ownsMTFInv_8u( pSrc, pDst, len, pMTFState->heap );

#else

    {
        Ipp8u *heap = pMTFState->heap;
        int   i, j;
        Ipp8u tmpCh;

        for ( i = 0; i < len; i++ )
        {
            j = (int)pSrc[i];
            tmpCh = pDst[i] = heap[j];
            if ( j )
            {
                ippsMove_8u( heap, heap + 1, j );
                heap[0] = tmpCh;
            }
        }
    }

#endif

    return ippStsNoErr;
} /* ippsMTFInv_8u */

