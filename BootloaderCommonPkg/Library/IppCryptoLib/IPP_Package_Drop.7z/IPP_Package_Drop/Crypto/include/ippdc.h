/*
// INTEL CONFIDENTIAL
// Copyright 2004 2017 Intel Corporation
// FOR INTEL INTERNAL USE ONLY.  THE SOURCE CODE CONTAINED OR DESCRIBED HEREIN
// MAY ONLY BE USED TO DEVELOP INTEL SOFTWARE PRODUCTS AND MAY ONLY BE
// REDISTRIBUTED IN BINARY FORM AS A COMPONENT OF SUCH INTEL SOFTWARE PRODUCTS.
// REDISTRIBUTION IN SOURCE CODE FORM IS NOT ALLOWED WITHOUT THE EXPLICIT
// WRITTEN APPROVAL OF THE DEVELOPER PRODUCT DIVISION.
// The source code contained or described herein and all documents related to
// the source code ("Material") are owned by Intel Corporation or its suppliers
// or licensors. Title to the Material remains with Intel Corporation or its
// suppliers and licensors. The Material contains trade secrets and proprietary
// and confidential information of Intel or its suppliers and licensors.
// The Material is protected by worldwide copyright and trade secret laws and
// treaty provisions. No part of the Material may be used, copied, reproduced,
// modified, published, uploaded, posted, transmitted, distributed, or disclosed
// in any way without Intel's prior express written permission.
// No license under any patent, copyright, trade secret or other intellectual
// property right is granted to or conferred upon you by disclosure or delivery
// of the Materials, either expressly, by implication, inducement, estoppel or
// otherwise. Any license under such intellectual property rights must be
// express and approved by Intel in writing.
// 
// Unless otherwise agreed by Intel in writing,
// you may not remove or alter this notice or any other notice embedded in
// Materials by Intel or Intel's suppliers or licensors in any way.
// 
*/

/* 
//              Intel(R) Integrated Performance Primitives (Intel(R) IPP)
//              Data Compression Library (ippDC)
// 
// 
*/


#if !defined( __IPPDC_H__ ) || defined( _OWN_BLDPCS )
#define __IPPDC_H__

#if defined (_WIN32_WCE) && defined (_M_IX86) && defined (__stdcall)
  #define _IPP_STDCALL_CDECL
  #undef __stdcall
#endif

#ifndef __IPPDEFS_H__
  #include "ippdefs.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if !defined( _IPP_NO_DEFAULT_LIB )
  #if defined( _IPP_SEQUENTIAL_DYNAMIC )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "ippdc" )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "ippcore" )
  #elif defined( _IPP_SEQUENTIAL_STATIC )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "ippdcmt" )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "ippsmt" )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "ippvmmt" )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "ippcoremt" )
  #elif defined( _IPP_PARALLEL_DYNAMIC )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "threaded/ippdc" )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "threaded/ippcore" )
  #elif defined( _IPP_PARALLEL_STATIC )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "threaded/ippdcmt" )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "threaded/ippsmt" )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "threaded/ippvmmt" )
    #pragma comment( lib, __FILE__ "/../../lib/" _INTEL_PLATFORM "threaded/ippcoremt" )
  #endif
#endif


/********************* Data Structures and Macro ****************************/

/* /////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//                   Functions declarations
////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////// */


/* /////////////////////////////////////////////////////////////////////////////
//  Name:       ippdcGetLibVersion
//  Purpose:    getting of the library version
//  Returns:    the structure of information about version
//              of ippDC library
//  Parameters:
//
//  Notes:      not necessary to release the returned structure
*/
IPPAPI( const IppLibraryVersion*, ippdcGetLibVersion, (void) )

/* Move To Front */

IPPAPI( IppStatus, ippsCRC32_8u, (const Ipp8u* pSrc, int srcLen, Ipp32u* pCRC32) )

/* /////////////////////////////////////////////////////////////////////////////
//  Name:               ippsCRC32C
//  Purpose:            Computes the CRC32C (the polinomial 0x11EDC6F41) value
//                      for the source vector.
//                      Reference: "Optimization of cyclic redundancy-check
//                      codes with 24 and 32 parity bits". Castagnoli, G.;
//                      Brauer, S.; Herrmann, M.; Communications,
//                      IEEE Transactions on Volume 41, Issue 6,
//                      June 1993 Page(s):883 - 892.
//
//  Parameters:
//   pSrc               Pointer to the source vector
//   srcLen             Length of the source vector
//   pCRC32C            Pointer to the CRC32C value
//  Return:
//   ippStsNoErr        No errors
//   ippStsNullPtrErr   One or several pointer(s) is NULL
//   ippStsSizeErr      Length of the source vector is equal zero
//
*/
IPPAPI( IppStatus, ippsCRC32C_8u, (const Ipp8u* pSrc, Ipp32u srcLen, Ipp32u* pCRC32C) )

/* /////////////////////////////////////////////////////////////////////////////
//  Name:               ippsCRC32_BZ2_8u
//  Purpose:            Performs the CRC32 checksum calculation according to the direct algorithm, which is used in bzip2.
//
//  Parameters:
//    pSrc              Pointer to the source data vector
//    srcLen            The length of source vector
//    pCRC32            Pointer to the value of accumulated CRC32
//
//  Return:
//    ippStsNullPtrErr          One or several pointer(s) is NULL
//    ippStsSizeErr             Length of the source vector is less or equal zero
//    ippStsNoErr               No errors
//
*/

IPPAPI(IppStatus, ippsCRC32_BZ2_8u,    ( const Ipp8u* pSrc, int srcLen, Ipp32u* pCRC32 ))

/**************************************************
Intel(R) IPP LZ4 Definitions
***************************************************/

/* /////////////////////////////////////////////////////////////////////////////
//  Name:       ippsDecodeLZ4_8u
//  Purpose:    LZ4 encoder
//
//  Arguments:
//      pSrc            pointer to source
//      srcLen          length of source
//      pDst            pointer to destination
//      pDstLen         pointer to size of buffer for destination / length of compressed data
//
//  Return:
//      ippStsNullPtrErr  one of the pointers is NULL
//      ippStsSizeErr     length of source or buffer destination is less or equal zero
//      ippStsNoErr       no error detected
//
*/
IPPAPI(IppStatus, ippsDecodeLZ4_8u,(const Ipp8u* pSrc, int srcLen, Ipp8u* pDst, int *pDstLen))


#ifdef __cplusplus
}
#endif

#if defined (_IPP_STDCALL_CDECL)
  #undef  _IPP_STDCALL_CDECL
  #define __stdcall __cdecl
#endif

#endif /* __IPPDC_H__ */
